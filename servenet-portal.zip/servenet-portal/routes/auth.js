/**
 * Authentication Routes
 * =====================
 * Handles login form display, login POST, and logout.
 * Tracks IP address, user-agent, and login time on each sign-in.
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { findUserByEmail, updateLoginInfo } = require('../models/database');

// ---------------------
// GET /login - Show login form
// ---------------------
router.get('/login', (req, res) => {
  // If already logged in, redirect to appropriate dashboard
  if (req.session.user) {
    return res.redirect(req.session.user.role === 'admin' ? '/admin' : '/customer');
  }
  res.render('login', { title: 'Login', error: null });
});

// ---------------------
// POST /login - Process login
// ---------------------
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Validate input
  if (!email || !password) {
    return res.render('login', { title: 'Login', error: 'Please enter both email and password.' });
  }

  // Look up user by email
  const user = findUserByEmail(email.trim().toLowerCase());
  if (!user) {
    return res.render('login', { title: 'Login', error: 'Invalid email or password.' });
  }

  // Verify password with bcrypt
  const passwordMatch = bcrypt.compareSync(password, user.password);
  if (!passwordMatch) {
    return res.render('login', { title: 'Login', error: 'Invalid email or password.' });
  }

  // Capture IP and user-agent for login tracking
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const userAgent = req.get('User-Agent') || 'unknown';

  // Update the user's login tracking fields in the database
  updateLoginInfo(user.id, ip, userAgent);

  // Store user info in session (exclude password hash)
  req.session.user = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    isBusiness: user.isBusiness,
    businessName: user.businessName,
    companiesHouseNumber: user.companiesHouseNumber,
    lastLoginTime: new Date().toISOString(),
    lastLoginIP: ip,
    lastDevice: userAgent
  };

  // Redirect based on role
  if (user.role === 'admin') {
    return res.redirect('/admin');
  }
  return res.redirect('/customer');
});

// ---------------------
// GET /logout - Destroy session and redirect
// ---------------------
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Session destroy error:', err);
    }
    res.redirect('/login');
  });
});

module.exports = router;
