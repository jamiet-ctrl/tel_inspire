/**
 * Authentication Routes v2
 * ========================
 * - Failed login attempt logging
 * - Account lockout after 3 failed attempts (30 min)
 * - Session timeout handling
 * - IP and device tracking
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const {
  findUserByEmail, updateLoginInfo, recordLoginAttempt,
  incrementFailedAttempts, isAccountLocked, createAuditLog, createNotification
} = require('../models/database');

// GET /login
router.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect(req.session.user.role === 'admin' ? '/admin' : '/customer');
  }

  const timeout = req.query.timeout === '1';
  const locked = req.query.locked === '1';

  res.render('login', {
    title: 'Login',
    error: timeout ? 'Your session has expired due to inactivity. Please sign in again.'
      : locked ? 'This account has been locked due to too many failed login attempts. Please try again later or contact support.'
      : null,
    isTimeout: timeout
  });
});

// POST /login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const userAgent = req.get('User-Agent') || 'unknown';

  if (!email || !password) {
    return res.render('login', {
      title: 'Login',
      error: 'Please enter both email and password.',
      isTimeout: false
    });
  }

  const cleanEmail = email.trim().toLowerCase();
  const user = findUserByEmail(cleanEmail);

  // User not found
  if (!user) {
    recordLoginAttempt(cleanEmail, ip, userAgent, false, 'Account not found');
    return res.render('login', {
      title: 'Login',
      error: 'Invalid email or password.',
      isTimeout: false
    });
  }

  // Check if account is locked
  if (isAccountLocked(user)) {
    recordLoginAttempt(cleanEmail, ip, userAgent, false, 'Account locked');
    return res.redirect('/login?locked=1');
  }

  // Verify password
  const passwordMatch = bcrypt.compareSync(password, user.password);

  if (!passwordMatch) {
    // Record failed attempt
    recordLoginAttempt(cleanEmail, ip, userAgent, false, 'Invalid password');
    const result = incrementFailedAttempts(user.id);

    if (result.locked) {
      // Log the lockout as an audit event
      createAuditLog({
        adminId: user.id,
        adminName: `${user.firstName} ${user.lastName}`,
        adminEmail: user.email,
        action: 'account_locked',
        category: 'security',
        reason: 'Automatic lockout',
        details: `Account locked after ${result.attempts} failed login attempts from IP ${ip}`,
        ipAddress: ip,
        userAgent: userAgent
      });

      // Create notification for all admins
      createNotification({
        type: 'account_locked',
        title: 'Account Locked',
        message: `${user.firstName} ${user.lastName} (${user.email}) has been locked after ${result.attempts} failed login attempts from IP ${ip}.`,
        targetAdminId: null, // null = visible to all admins
        relatedUserId: user.id
      });

      return res.redirect('/login?locked=1');
    }

    return res.render('login', {
      title: 'Login',
      error: `Invalid email or password. ${result.remaining} attempt${result.remaining !== 1 ? 's' : ''} remaining before account lockout.`,
      isTimeout: false
    });
  }

  // Check if account is active (could be suspended by admin)
  if (user.accountStatus === 'suspended') {
    recordLoginAttempt(cleanEmail, ip, userAgent, false, 'Account suspended');
    return res.render('login', {
      title: 'Login',
      error: 'This account has been suspended. Please contact support.',
      isTimeout: false
    });
  }

  // Successful login
  recordLoginAttempt(cleanEmail, ip, userAgent, true);
  updateLoginInfo(user.id, ip, userAgent);

  req.session.user = {
    id: user.id,
    name: `${user.firstName} ${user.lastName}`,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    role: user.role,
    isBusiness: user.isBusiness,
    businessName: user.businessName,
    companiesHouseNumber: user.companiesHouseNumber
  };
  req.session.lastActivity = Date.now();

  // Log ALL logins in audit trail
  createAuditLog({
    adminId: user.id,
    adminName: `${user.firstName} ${user.lastName}`,
    adminEmail: user.email,
    action: user.role === 'admin' ? 'login' : 'customer_login',
    category: 'security',
    targetUserId: user.id,
    targetUserName: `${user.firstName} ${user.lastName}`,
    targetUserEmail: user.email,
    reason: user.role === 'admin' ? 'Admin login' : 'Customer login',
    details: `${user.role === 'admin' ? 'Admin' : 'Customer'} logged in from IP ${ip}`,
    ipAddress: ip,
    userAgent: userAgent
  });

  if (user.role === 'admin') return res.redirect('/admin');
  return res.redirect('/customer');
});

// GET /logout
router.get('/logout', (req, res) => {
  if (req.session.user) {
    const isAdmin = req.session.user.role === 'admin';
    createAuditLog({
      adminId: req.session.user.id,
      adminName: req.session.user.name,
      adminEmail: req.session.user.email,
      action: isAdmin ? 'logout' : 'customer_logout',
      category: 'security',
      targetUserId: req.session.user.id,
      targetUserName: req.session.user.name,
      targetUserEmail: req.session.user.email,
      reason: isAdmin ? 'Admin logout' : 'Customer logout',
      details: `${isAdmin ? 'Admin' : 'Customer'} logged out manually`,
      ipAddress: req.ip || 'unknown'
    });
  }

  req.session.destroy((err) => {
    if (err) console.error('Session destroy error:', err);
    res.redirect('/login');
  });
});

module.exports = router;
