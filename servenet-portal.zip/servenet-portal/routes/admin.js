/**
 * Admin Dashboard Routes v2
 * =========================
 * - Separate residential/business customer search pages
 * - Improved audit log with filtering and search
 * - User management with vulnerability tracking
 * - Account unlock capability
 * - Failed login viewer
 * - All actions create compliance audit entries
 */

const express = require('express');
const router = express.Router();
const {
  findUserById, getAllUsers,
  searchCustomers, searchBusinessCustomers,
  updateUser, unlockAccount,
  createAuditLog, getAuditLogs, getAuditStats,
  getLoginAttempts
} = require('../models/database');

// Middleware: require admin
function requireAdmin(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  if (req.session.user.role !== 'admin') {
    return res.status(403).render('error', {
      title: '403 - Access Denied',
      message: 'You do not have permission to access the admin dashboard.'
    });
  }
  next();
}

router.use(requireAdmin);

// Audit reasons
const AUDIT_REASONS = [
  'Account verification',
  'Customer support',
  'Billing issue',
  'Fraud prevention',
  'Technical support',
  'Vulnerability assessment',
  'Complaint handling',
  'Service provisioning',
  'Regulatory request',
  'Account maintenance'
];

// =====================
// Dashboard / Welcome
// =====================

router.get('/', (req, res) => {
  const stats = getAuditStats();
  res.render('admin/welcome', {
    title: 'Admin Dashboard',
    user: req.session.user,
    stats,
    activePage: 'dashboard'
  });
});

// =====================
// Customer Search (Residential)
// =====================

router.get('/customers', (req, res) => {
  const query = req.query.q || '';
  const vulnerableOnly = req.query.vulnerable === '1';
  const postcodeFilter = req.query.postcode || '';

  const customers = searchCustomers(query, {
    vulnerableOnly,
    postcode: postcodeFilter
  });

  res.render('admin/customers', {
    title: 'Customer Search',
    user: req.session.user,
    customers,
    query,
    vulnerableOnly,
    postcodeFilter,
    activePage: 'customers'
  });
});

// =====================
// Business Search
// =====================

router.get('/business', (req, res) => {
  const query = req.query.q || '';
  const postcodeFilter = req.query.postcode || '';

  const businesses = searchBusinessCustomers(query, {
    postcode: postcodeFilter
  });

  res.render('admin/business', {
    title: 'Business Accounts',
    user: req.session.user,
    businesses,
    query,
    postcodeFilter,
    activePage: 'business'
  });
});

// =====================
// View User (with reason gate)
// =====================

router.get('/users/:id', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404 - User Not Found',
      message: 'The requested user does not exist.'
    });
  }

  const reason = req.query.reason;
  const confirmed = req.query.confirmed === 'true';

  if (confirmed && reason && AUDIT_REASONS.includes(reason)) {
    createAuditLog({
      adminId: req.session.user.id,
      adminName: req.session.user.name,
      adminEmail: req.session.user.email,
      action: 'viewed',
      category: 'data_access',
      targetUserId: targetUser.id,
      targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
      targetUserEmail: targetUser.email,
      reason: reason,
      details: `Viewed full account record for customer #${targetUser.id} (${targetUser.email})`,
      ipAddress: req.ip || 'unknown',
      userAgent: req.get('User-Agent') || 'unknown'
    });

    return res.render('admin/user-view', {
      title: `User: ${targetUser.firstName} ${targetUser.lastName}`,
      user: req.session.user,
      targetUser,
      activePage: 'customers',
      auditLogged: true
    });
  }

  res.render('admin/user-reason', {
    title: `Access User: ${targetUser.firstName} ${targetUser.lastName}`,
    user: req.session.user,
    targetUser,
    reasons: AUDIT_REASONS,
    actionType: 'view',
    activePage: 'customers'
  });
});

// =====================
// Edit User
// =====================

router.get('/users/:id/edit', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404 - User Not Found',
      message: 'The requested user does not exist.'
    });
  }

  const reason = req.query.reason;
  const confirmed = req.query.confirmed === 'true';

  if (confirmed && reason && AUDIT_REASONS.includes(reason)) {
    createAuditLog({
      adminId: req.session.user.id,
      adminName: req.session.user.name,
      adminEmail: req.session.user.email,
      action: 'accessed_edit',
      category: 'data_access',
      targetUserId: targetUser.id,
      targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
      targetUserEmail: targetUser.email,
      reason: reason,
      details: `Opened edit form for customer #${targetUser.id}`,
      ipAddress: req.ip || 'unknown',
      userAgent: req.get('User-Agent') || 'unknown'
    });

    return res.render('admin/user-edit', {
      title: `Edit: ${targetUser.firstName} ${targetUser.lastName}`,
      user: req.session.user,
      targetUser,
      activePage: 'customers',
      reasons: AUDIT_REASONS,
      editReason: reason,
      success: null,
      error: null
    });
  }

  res.render('admin/user-reason', {
    title: `Edit User: ${targetUser.firstName} ${targetUser.lastName}`,
    user: req.session.user,
    targetUser,
    reasons: AUDIT_REASONS,
    actionType: 'edit',
    activePage: 'customers'
  });
});

router.post('/users/:id/edit', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404 - User Not Found',
      message: 'The requested user does not exist.'
    });
  }

  const {
    firstName, lastName, role, isBusiness, businessName,
    companiesHouseNumber, postcode, addressLine1, addressLine2,
    city, phone, isVulnerable, vulnerabilityNotes, accountStatus, reason
  } = req.body;

  if (!firstName || !firstName.trim() || !lastName || !lastName.trim()) {
    return res.render('admin/user-edit', {
      title: `Edit: ${targetUser.firstName} ${targetUser.lastName}`,
      user: req.session.user,
      targetUser,
      activePage: 'customers',
      reasons: AUDIT_REASONS,
      editReason: reason || 'Customer support',
      success: null,
      error: 'First name and last name are required.'
    });
  }

  const auditReason = reason && AUDIT_REASONS.includes(reason) ? reason : 'Customer support';

  // Capture previous values for audit trail
  const previousValues = JSON.stringify({
    firstName: targetUser.firstName, lastName: targetUser.lastName,
    role: targetUser.role, isBusiness: targetUser.isBusiness,
    businessName: targetUser.businessName, companiesHouseNumber: targetUser.companiesHouseNumber,
    postcode: targetUser.postcode, addressLine1: targetUser.addressLine1,
    city: targetUser.city, phone: targetUser.phone,
    isVulnerable: targetUser.isVulnerable, vulnerabilityNotes: targetUser.vulnerabilityNotes,
    accountStatus: targetUser.accountStatus
  });

  const newData = {
    firstName: firstName.trim(),
    lastName: lastName.trim(),
    role: role === 'admin' ? 'admin' : 'customer',
    isBusiness: isBusiness === 'on' || isBusiness === '1',
    businessName: businessName ? businessName.trim() : null,
    companiesHouseNumber: companiesHouseNumber ? companiesHouseNumber.trim() : null,
    postcode: postcode ? postcode.trim().toUpperCase() : null,
    addressLine1: addressLine1 ? addressLine1.trim() : null,
    addressLine2: addressLine2 ? addressLine2.trim() : null,
    city: city ? city.trim() : null,
    phone: phone ? phone.trim() : null,
    isVulnerable: isVulnerable === 'on' || isVulnerable === '1',
    vulnerabilityNotes: vulnerabilityNotes ? vulnerabilityNotes.trim() : null,
    accountStatus: ['active', 'suspended', 'locked'].includes(accountStatus) ? accountStatus : 'active'
  };

  // Build change summary
  const changes = [];
  if (newData.firstName !== targetUser.firstName) changes.push(`firstName: "${targetUser.firstName}" → "${newData.firstName}"`);
  if (newData.lastName !== targetUser.lastName) changes.push(`lastName: "${targetUser.lastName}" → "${newData.lastName}"`);
  if (newData.role !== targetUser.role) changes.push(`role: "${targetUser.role}" → "${newData.role}"`);
  if ((newData.isBusiness ? 1 : 0) !== targetUser.isBusiness) changes.push(`isBusiness: ${targetUser.isBusiness} → ${newData.isBusiness ? 1 : 0}`);
  if ((newData.businessName || '') !== (targetUser.businessName || '')) changes.push(`businessName changed`);
  if ((newData.postcode || '') !== (targetUser.postcode || '')) changes.push(`postcode: "${targetUser.postcode || ''}" → "${newData.postcode || ''}"`);
  if ((newData.isVulnerable ? 1 : 0) !== targetUser.isVulnerable) changes.push(`isVulnerable: ${targetUser.isVulnerable} → ${newData.isVulnerable ? 1 : 0}`);
  if (newData.accountStatus !== targetUser.accountStatus) changes.push(`accountStatus: "${targetUser.accountStatus}" → "${newData.accountStatus}"`);
  if ((newData.phone || '') !== (targetUser.phone || '')) changes.push(`phone updated`);

  updateUser(targetUser.id, newData);

  createAuditLog({
    adminId: req.session.user.id,
    adminName: req.session.user.name,
    adminEmail: req.session.user.email,
    action: 'edited',
    category: 'data_modification',
    targetUserId: targetUser.id,
    targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
    targetUserEmail: targetUser.email,
    reason: auditReason,
    details: changes.length > 0 ? `Changed: ${changes.join('; ')}` : 'No fields changed',
    previousValues: previousValues,
    newValues: JSON.stringify(newData),
    ipAddress: req.ip || 'unknown',
    userAgent: req.get('User-Agent') || 'unknown'
  });

  const updatedUser = findUserById(targetUser.id);

  res.render('admin/user-edit', {
    title: `Edit: ${updatedUser.firstName} ${updatedUser.lastName}`,
    user: req.session.user,
    targetUser: updatedUser,
    activePage: 'customers',
    reasons: AUDIT_REASONS,
    editReason: auditReason,
    success: 'User updated successfully. Changes recorded in audit log.',
    error: null
  });
});

// =====================
// Unlock Account
// =====================

router.post('/users/:id/unlock', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404', message: 'User not found.'
    });
  }

  unlockAccount(targetUser.id);

  createAuditLog({
    adminId: req.session.user.id,
    adminName: req.session.user.name,
    adminEmail: req.session.user.email,
    action: 'unlocked_account',
    category: 'security',
    targetUserId: targetUser.id,
    targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
    targetUserEmail: targetUser.email,
    reason: 'Account maintenance',
    details: `Manually unlocked account for ${targetUser.email}`,
    ipAddress: req.ip || 'unknown',
    userAgent: req.get('User-Agent') || 'unknown'
  });

  req.session.flash = { type: 'success', message: `Account for ${targetUser.firstName} ${targetUser.lastName} has been unlocked.` };
  res.redirect(`/admin/users/${targetUser.id}?reason=Account+maintenance&confirmed=true`);
});

// =====================
// Audit Log
// =====================

router.get('/audit', (req, res) => {
  const filters = {
    search: req.query.search || '',
    action: req.query.action || '',
    category: req.query.category || '',
    reason: req.query.reason || '',
    dateFrom: req.query.dateFrom || '',
    dateTo: req.query.dateTo || ''
  };

  const logs = getAuditLogs(filters);
  const stats = getAuditStats();

  res.render('admin/audit', {
    title: 'Audit Log',
    user: req.session.user,
    logs,
    stats,
    filters,
    reasons: AUDIT_REASONS,
    activePage: 'audit'
  });
});

// =====================
// Security - Failed Login Attempts
// =====================

router.get('/security', (req, res) => {
  const filters = {
    email: req.query.email || '',
    failedOnly: req.query.failed === '1'
  };

  const attempts = getLoginAttempts(filters);
  const stats = getAuditStats();

  res.render('admin/security', {
    title: 'Security Log',
    user: req.session.user,
    attempts,
    stats,
    filters,
    activePage: 'security'
  });
});

module.exports = router;
