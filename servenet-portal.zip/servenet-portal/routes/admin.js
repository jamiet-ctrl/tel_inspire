/**
 * Admin Routes v4
 * ================
 * - Separate residential/business customer search
 * - Paginated audit log (50/page) with Excel export
 * - Customer autocomplete for audit filtering
 * - User view with accordions + services
 * - User edit with full OFCOM compliance
 * - Account unlock
 * - Failed login viewer
 * - Notifications
 * - Admin settings (profile + password)
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const {
  findUserById, findUserByEmail, getAllUsers,
  searchCustomers, searchBusinessCustomers,
  updateUser, updateUserPassword, updateUserProfile, unlockAccount,
  createAuditLog, getAuditLogs, getAuditLogsAll, getAuditStats,
  getLoginAttempts, getServicesForUser,
  autocompleteUsers,
  createNotification, getAllNotifications, markNotificationRead, markAllNotificationsRead
} = require('../models/database');

function requireAdmin(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  if (req.session.user.role !== 'admin') {
    return res.status(403).render('error', { title: '403', message: 'Access denied.' });
  }
  next();
}
router.use(requireAdmin);

const AUDIT_REASONS = [
  'Account verification', 'Customer support', 'Billing issue',
  'Fraud prevention', 'Technical support', 'Vulnerability assessment',
  'Complaint handling', 'Service provisioning', 'Regulatory request', 'Account maintenance',
  'Self-service', 'Customer login', 'Customer logout', 'Admin login', 'Admin logout', 'Automatic lockout'
];

// ===================== Dashboard =====================
router.get('/', (req, res) => {
  const stats = getAuditStats();
  res.render('admin/welcome', { title: 'Dashboard', stats, activePage: 'dashboard' });
});

// ===================== Customers (Residential) =====================
router.get('/customers', (req, res) => {
  const query = req.query.q || '';
  const vulnerableOnly = req.query.vulnerable === '1';
  const postcodeFilter = req.query.postcode || '';
  const customers = searchCustomers(query, { vulnerableOnly, postcode: postcodeFilter });
  res.render('admin/customers', {
    title: 'Customers', customers, query, vulnerableOnly, postcodeFilter, activePage: 'customers'
  });
});

// ===================== Business =====================
router.get('/business', (req, res) => {
  const query = req.query.q || '';
  const postcodeFilter = req.query.postcode || '';
  const businesses = searchBusinessCustomers(query, { postcode: postcodeFilter });
  res.render('admin/business', {
    title: 'Business Accounts', businesses, query, postcodeFilter, activePage: 'business'
  });
});

// ===================== View User =====================
router.get('/users/:id', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) return res.status(404).render('error', { title: '404', message: 'User not found.' });

  const reason = req.query.reason;
  const confirmed = req.query.confirmed === 'true';

  if (confirmed && reason && AUDIT_REASONS.includes(reason)) {
    createAuditLog({
      adminId: req.session.user.id, adminName: req.session.user.name, adminEmail: req.session.user.email,
      action: 'viewed', category: 'data_access',
      targetUserId: targetUser.id, targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
      targetUserEmail: targetUser.email, reason,
      details: `Viewed full record for #${targetUser.id}`,
      ipAddress: req.ip || 'unknown', userAgent: req.get('User-Agent') || 'unknown'
    });
    return res.render('admin/user-view', {
      title: `${targetUser.firstName} ${targetUser.lastName}`,
      targetUser, services: getServicesForUser(targetUser.id),
      activePage: targetUser.isBusiness ? 'business' : 'customers', auditLogged: true
    });
  }

  res.render('admin/user-reason', {
    title: 'Access User', targetUser, reasons: AUDIT_REASONS,
    actionType: 'view', activePage: targetUser.isBusiness ? 'business' : 'customers'
  });
});

// ===================== Edit User =====================
router.get('/users/:id/edit', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) return res.status(404).render('error', { title: '404', message: 'User not found.' });

  const reason = req.query.reason;
  const confirmed = req.query.confirmed === 'true';

  if (confirmed && reason && AUDIT_REASONS.includes(reason)) {
    createAuditLog({
      adminId: req.session.user.id, adminName: req.session.user.name, adminEmail: req.session.user.email,
      action: 'accessed_edit', category: 'data_access',
      targetUserId: targetUser.id, targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
      targetUserEmail: targetUser.email, reason,
      details: `Opened edit form for #${targetUser.id}`,
      ipAddress: req.ip || 'unknown', userAgent: req.get('User-Agent') || 'unknown'
    });
    return res.render('admin/user-edit', {
      title: `Edit: ${targetUser.firstName} ${targetUser.lastName}`,
      targetUser, reasons: AUDIT_REASONS, editReason: reason,
      activePage: targetUser.isBusiness ? 'business' : 'customers',
      success: null, error: null
    });
  }

  res.render('admin/user-reason', {
    title: 'Edit User', targetUser, reasons: AUDIT_REASONS,
    actionType: 'edit', activePage: targetUser.isBusiness ? 'business' : 'customers'
  });
});

router.post('/users/:id/edit', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) return res.status(404).render('error', { title: '404', message: 'User not found.' });

  const {
    firstName, lastName, role, isBusiness, businessName, companiesHouseNumber,
    postcode, addressLine1, addressLine2, city, phone,
    isVulnerable, vulnerabilityNotes, accountStatus, reason
  } = req.body;

  if (!firstName?.trim() || !lastName?.trim()) {
    return res.render('admin/user-edit', {
      title: `Edit: ${targetUser.firstName} ${targetUser.lastName}`,
      targetUser, reasons: AUDIT_REASONS, editReason: reason || 'Customer support',
      activePage: 'customers', success: null, error: 'First and last name are required.'
    });
  }

  const auditReason = AUDIT_REASONS.includes(reason) ? reason : 'Customer support';
  const previousValues = JSON.stringify({
    firstName: targetUser.firstName, lastName: targetUser.lastName,
    postcode: targetUser.postcode, isVulnerable: targetUser.isVulnerable,
    accountStatus: targetUser.accountStatus
  });

  const newData = {
    firstName: firstName.trim(), lastName: lastName.trim(),
    role: role === 'admin' ? 'admin' : 'customer',
    isBusiness: isBusiness === 'on' || isBusiness === '1',
    businessName: businessName?.trim() || null,
    companiesHouseNumber: companiesHouseNumber?.trim() || null,
    postcode: postcode?.trim().toUpperCase() || null,
    addressLine1: addressLine1?.trim() || null, addressLine2: addressLine2?.trim() || null,
    city: city?.trim() || null, phone: phone?.trim() || null,
    isVulnerable: isVulnerable === 'on' || isVulnerable === '1',
    vulnerabilityNotes: vulnerabilityNotes?.trim() || null,
    accountStatus: ['active', 'suspended', 'locked'].includes(accountStatus) ? accountStatus : 'active'
  };

  const changes = [];
  if (newData.firstName !== targetUser.firstName) changes.push(`name: ${targetUser.firstName} → ${newData.firstName}`);
  if (newData.lastName !== targetUser.lastName) changes.push(`surname: ${targetUser.lastName} → ${newData.lastName}`);
  if ((newData.isVulnerable ? 1 : 0) !== targetUser.isVulnerable) changes.push(`vulnerable: ${targetUser.isVulnerable} → ${newData.isVulnerable ? 1 : 0}`);
  if (newData.accountStatus !== targetUser.accountStatus) changes.push(`status: ${targetUser.accountStatus} → ${newData.accountStatus}`);

  updateUser(targetUser.id, newData);

  createAuditLog({
    adminId: req.session.user.id, adminName: req.session.user.name, adminEmail: req.session.user.email,
    action: 'edited', category: 'data_modification',
    targetUserId: targetUser.id, targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
    targetUserEmail: targetUser.email, reason: auditReason,
    details: changes.length > 0 ? `Changed: ${changes.join('; ')}` : 'No fields changed',
    previousValues, newValues: JSON.stringify(newData),
    ipAddress: req.ip || 'unknown', userAgent: req.get('User-Agent') || 'unknown'
  });

  const updatedUser = findUserById(targetUser.id);
  res.render('admin/user-edit', {
    title: `Edit: ${updatedUser.firstName} ${updatedUser.lastName}`,
    targetUser: updatedUser, reasons: AUDIT_REASONS, editReason: auditReason,
    activePage: 'customers', success: 'Saved. Changes recorded in audit log.', error: null
  });
});

// ===================== Unlock Account =====================
router.post('/users/:id/unlock', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) return res.status(404).render('error', { title: '404', message: 'User not found.' });

  unlockAccount(targetUser.id);
  createAuditLog({
    adminId: req.session.user.id, adminName: req.session.user.name, adminEmail: req.session.user.email,
    action: 'unlocked_account', category: 'security',
    targetUserId: targetUser.id, targetUserName: `${targetUser.firstName} ${targetUser.lastName}`,
    targetUserEmail: targetUser.email, reason: 'Account maintenance',
    details: `Unlocked ${targetUser.email}`, ipAddress: req.ip || 'unknown'
  });
  req.session.flash = { type: 'success', message: `${targetUser.firstName} ${targetUser.lastName} has been unlocked.` };
  res.redirect(`/admin/users/${targetUser.id}?reason=Account+maintenance&confirmed=true`);
});

// ===================== Audit Log (paginated) =====================
router.get('/audit', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const filters = {
    search: req.query.search || '', action: req.query.action || '',
    category: req.query.category || '', reason: req.query.reason || '',
    targetUserId: req.query.targetUserId || '',
    dateFrom: req.query.dateFrom || '', dateTo: req.query.dateTo || ''
  };

  const result = getAuditLogs(filters, page, 50);
  const stats = getAuditStats();

  // Build query string for pagination links (preserve filters)
  const qs = Object.entries(filters).filter(([,v]) => v).map(([k,v]) => `${k}=${encodeURIComponent(v)}`).join('&');

  res.render('admin/audit', {
    title: 'Audit Log', logs: result.rows, total: result.total,
    page: result.page, totalPages: result.totalPages,
    stats, filters, reasons: AUDIT_REASONS, filterQs: qs,
    activePage: 'audit'
  });
});

// ===================== Audit Export to Excel =====================
router.get('/audit/export', async (req, res) => {
  const filters = {
    search: req.query.search || '', action: req.query.action || '',
    category: req.query.category || '', reason: req.query.reason || '',
    targetUserId: req.query.targetUserId || '',
    dateFrom: req.query.dateFrom || '', dateTo: req.query.dateTo || ''
  };

  const logs = getAuditLogsAll(filters);

  // Log the export action
  createAuditLog({
    adminId: req.session.user.id, adminName: req.session.user.name, adminEmail: req.session.user.email,
    action: 'exported_audit', category: 'data_access', reason: 'Regulatory request',
    details: `Exported ${logs.length} audit entries to Excel. Filters: ${JSON.stringify(filters)}`,
    ipAddress: req.ip || 'unknown'
  });

  const ExcelJS = require('exceljs');
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'ServeNet Portal';
  workbook.created = new Date();

  const sheet = workbook.addWorksheet('Audit Log');
  sheet.columns = [
    { header: 'ID', key: 'id', width: 8 },
    { header: 'Timestamp', key: 'timestamp', width: 20 },
    { header: 'Admin', key: 'adminName', width: 18 },
    { header: 'Admin Email', key: 'adminEmail', width: 24 },
    { header: 'Action', key: 'action', width: 16 },
    { header: 'Category', key: 'category', width: 16 },
    { header: 'Customer ID', key: 'targetUserId', width: 12 },
    { header: 'Customer Name', key: 'targetUserName', width: 20 },
    { header: 'Customer Email', key: 'targetUserEmail', width: 24 },
    { header: 'Reason', key: 'reason', width: 20 },
    { header: 'Details', key: 'details', width: 40 },
    { header: 'IP Address', key: 'ipAddress', width: 16 }
  ];

  // Header style
  sheet.getRow(1).eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0E2A3F' } };
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
    cell.alignment = { vertical: 'middle' };
  });

  logs.forEach(log => sheet.addRow(log));

  // Auto-filter
  sheet.autoFilter = { from: 'A1', to: 'L1' };

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  const datestamp = new Date().toISOString().split('T')[0];
  res.setHeader('Content-Disposition', `attachment; filename=ServeNet_Audit_${datestamp}.xlsx`);

  await workbook.xlsx.write(res);
  res.end();
});

// ===================== Customer Autocomplete API =====================
router.get('/api/autocomplete-users', (req, res) => {
  const q = req.query.q || '';
  const results = autocompleteUsers(q);
  res.json(results.map(u => ({
    id: u.id,
    label: `#${u.id} — ${u.firstName} ${u.lastName} (${u.email})${u.businessName ? ' — ' + u.businessName : ''}`,
    name: `${u.firstName} ${u.lastName}`
  })));
});

// ===================== Security Log =====================
router.get('/security', (req, res) => {
  const filters = { email: req.query.email || '', failedOnly: req.query.failed === '1' };
  const attempts = getLoginAttempts(filters);
  const stats = getAuditStats();
  res.render('admin/security', { title: 'Security', attempts, stats, filters, activePage: 'security' });
});

// ===================== Notifications =====================
router.get('/notifications', (req, res) => {
  const allNotifs = getAllNotifications(req.session.user.id);
  res.render('admin/notifications', { title: 'Notifications', allNotifications: allNotifs, activePage: 'notifications' });
});

router.post('/notifications/read/:id', (req, res) => {
  markNotificationRead(parseInt(req.params.id));
  res.json({ success: true });
});

router.post('/notifications/read-all', (req, res) => {
  markAllNotificationsRead(req.session.user.id);
  res.redirect(req.get('Referer') || '/admin/notifications');
});

// ===================== Admin Settings =====================
router.get('/settings', (req, res) => {
  const adminUser = findUserById(req.session.user.id);
  res.render('admin/settings', {
    title: 'Settings', adminUser, activePage: 'settings',
    success: null, error: null, tab: req.query.tab || 'profile'
  });
});

router.post('/settings/profile', (req, res) => {
  const { firstName, lastName, phone, addressLine1, addressLine2, city, postcode } = req.body;
  if (!firstName?.trim() || !lastName?.trim()) {
    const adminUser = findUserById(req.session.user.id);
    return res.render('admin/settings', {
      title: 'Settings', adminUser, activePage: 'settings',
      success: null, error: 'First and last name are required.', tab: 'profile'
    });
  }

  updateUserProfile(req.session.user.id, {
    firstName: firstName.trim(), lastName: lastName.trim(),
    phone: phone?.trim() || null, addressLine1: addressLine1?.trim() || null,
    addressLine2: addressLine2?.trim() || null, city: city?.trim() || null,
    postcode: postcode?.trim().toUpperCase() || null
  });

  // Update session
  req.session.user.name = `${firstName.trim()} ${lastName.trim()}`;
  req.session.user.firstName = firstName.trim();
  req.session.user.lastName = lastName.trim();

  const adminUser = findUserById(req.session.user.id);
  res.render('admin/settings', {
    title: 'Settings', adminUser, activePage: 'settings',
    success: 'Profile updated.', error: null, tab: 'profile'
  });
});

router.post('/settings/password', (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const adminUser = findUserById(req.session.user.id);

  if (!currentPassword || !newPassword || !confirmPassword) {
    return res.render('admin/settings', {
      title: 'Settings', adminUser, activePage: 'settings',
      success: null, error: 'All password fields are required.', tab: 'password'
    });
  }
  if (!bcrypt.compareSync(currentPassword, adminUser.password)) {
    return res.render('admin/settings', {
      title: 'Settings', adminUser, activePage: 'settings',
      success: null, error: 'Current password is incorrect.', tab: 'password'
    });
  }
  if (newPassword.length < 8) {
    return res.render('admin/settings', {
      title: 'Settings', adminUser, activePage: 'settings',
      success: null, error: 'New password must be at least 8 characters.', tab: 'password'
    });
  }
  if (newPassword !== confirmPassword) {
    return res.render('admin/settings', {
      title: 'Settings', adminUser, activePage: 'settings',
      success: null, error: 'Passwords do not match.', tab: 'password'
    });
  }

  updateUserPassword(adminUser.id, bcrypt.hashSync(newPassword, 10));

  createAuditLog({
    adminId: adminUser.id, adminName: req.session.user.name, adminEmail: req.session.user.email,
    action: 'password_changed', category: 'security', reason: 'Account maintenance',
    details: 'Admin changed their own password', ipAddress: req.ip || 'unknown'
  });

  const refreshed = findUserById(req.session.user.id);
  res.render('admin/settings', {
    title: 'Settings', adminUser: refreshed, activePage: 'settings',
    success: 'Password changed successfully.', error: null, tab: 'password'
  });
});

module.exports = router;
