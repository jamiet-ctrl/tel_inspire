/**
 * Admin Dashboard Routes
 * ======================
 * Protected routes for admin users only.
 * Includes: welcome, user list, user view, user edit, and audit log.
 * Every view/edit action triggers a compliance audit log entry.
 */

const express = require('express');
const router = express.Router();
const {
  findUserById,
  getAllUsers,
  updateUser,
  createAuditLog,
  getAllAuditLogs
} = require('../models/database');

// ---------------------
// Middleware: require admin role
// ---------------------
function requireAdmin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  if (req.session.user.role !== 'admin') {
    return res.status(403).render('error', {
      title: '403 - Access Denied',
      message: 'You do not have permission to access the admin dashboard.'
    });
  }
  next();
}

// Apply admin middleware to all routes in this file
router.use(requireAdmin);

// Audit log reason options (used in forms and validation)
const AUDIT_REASONS = [
  'Account verification',
  'Customer support',
  'Billing issue',
  'Fraud prevention',
  'Technical support'
];

// ---------------------
// GET /admin - Admin welcome page
// ---------------------
router.get('/', (req, res) => {
  res.render('admin/welcome', {
    title: 'Admin Dashboard',
    user: req.session.user,
    activePage: 'welcome'
  });
});

// ---------------------
// GET /admin/users - User list table
// ---------------------
router.get('/users', (req, res) => {
  const users = getAllUsers();
  res.render('admin/users', {
    title: 'User Management',
    user: req.session.user,
    users,
    activePage: 'users'
  });
});

// ---------------------
// GET /admin/users/:id - View a single user (triggers audit log)
// ---------------------
router.get('/users/:id', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404 - User Not Found',
      message: 'The requested user does not exist.'
    });
  }

  // Show the reason selection form before logging the view
  // The reason is submitted via query param after selection
  const reason = req.query.reason;
  const confirmed = req.query.confirmed === 'true';

  if (confirmed && reason && AUDIT_REASONS.includes(reason)) {
    // Log the view action
    createAuditLog({
      adminId: req.session.user.id,
      adminName: req.session.user.name,
      action: 'viewed',
      targetUserId: targetUser.id,
      targetUserName: targetUser.name,
      reason: reason,
      details: `Viewed full account details for ${targetUser.email}`,
      ipAddress: req.ip || 'unknown'
    });

    return res.render('admin/user-view', {
      title: `User: ${targetUser.name}`,
      user: req.session.user,
      targetUser,
      activePage: 'users',
      auditLogged: true
    });
  }

  // Show reason selection prompt before revealing user data
  res.render('admin/user-reason', {
    title: `Access User: ${targetUser.name}`,
    user: req.session.user,
    targetUser,
    reasons: AUDIT_REASONS,
    actionType: 'view',
    activePage: 'users'
  });
});

// ---------------------
// GET /admin/users/:id/edit - Show edit form (triggers audit log)
// ---------------------
router.get('/users/:id/edit', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404 - User Not Found',
      message: 'The requested user does not exist.'
    });
  }

  const reason = req.query.reason;
  const confirmed = req.query.confirmed === 'true';

  if (confirmed && reason && AUDIT_REASONS.includes(reason)) {
    // Log that admin accessed the edit form
    createAuditLog({
      adminId: req.session.user.id,
      adminName: req.session.user.name,
      action: 'clicked',
      targetUserId: targetUser.id,
      targetUserName: targetUser.name,
      reason: reason,
      details: `Opened edit form for ${targetUser.email}`,
      ipAddress: req.ip || 'unknown'
    });

    return res.render('admin/user-edit', {
      title: `Edit: ${targetUser.name}`,
      user: req.session.user,
      targetUser,
      activePage: 'users',
      reasons: AUDIT_REASONS,
      editReason: reason,
      success: null,
      error: null
    });
  }

  // Show reason selection prompt before showing edit form
  res.render('admin/user-reason', {
    title: `Edit User: ${targetUser.name}`,
    user: req.session.user,
    targetUser,
    reasons: AUDIT_REASONS,
    actionType: 'edit',
    activePage: 'users'
  });
});

// ---------------------
// POST /admin/users/:id/edit - Process user edit (triggers audit log)
// ---------------------
router.post('/users/:id/edit', (req, res) => {
  const targetUser = findUserById(parseInt(req.params.id));
  if (!targetUser) {
    return res.status(404).render('error', {
      title: '404 - User Not Found',
      message: 'The requested user does not exist.'
    });
  }

  const { name, role, isBusiness, businessName, companiesHouseNumber, reason } = req.body;

  // Validate required fields
  if (!name || !name.trim()) {
    return res.render('admin/user-edit', {
      title: `Edit: ${targetUser.name}`,
      user: req.session.user,
      targetUser,
      activePage: 'users',
      reasons: AUDIT_REASONS,
      editReason: reason || 'Customer support',
      success: null,
      error: 'Name is required.'
    });
  }

  // Validate reason
  const auditReason = reason && AUDIT_REASONS.includes(reason) ? reason : 'Customer support';

  // Build a details string showing what changed
  const changes = [];
  if (name.trim() !== targetUser.name) changes.push(`name: "${targetUser.name}" → "${name.trim()}"`);
  if (role !== targetUser.role) changes.push(`role: "${targetUser.role}" → "${role}"`);
  const newIsBusiness = isBusiness === 'on' || isBusiness === '1' ? 1 : 0;
  if (newIsBusiness !== targetUser.isBusiness) changes.push(`isBusiness: ${targetUser.isBusiness} → ${newIsBusiness}`);
  if ((businessName || '') !== (targetUser.businessName || '')) changes.push(`businessName: "${targetUser.businessName || ''}" → "${businessName || ''}"`);
  if ((companiesHouseNumber || '') !== (targetUser.companiesHouseNumber || '')) changes.push(`companiesHouseNumber: "${targetUser.companiesHouseNumber || ''}" → "${companiesHouseNumber || ''}"`);

  // Update the user record
  updateUser(targetUser.id, {
    name: name.trim(),
    role: role === 'admin' ? 'admin' : 'customer',
    isBusiness: newIsBusiness,
    businessName: businessName ? businessName.trim() : null,
    companiesHouseNumber: companiesHouseNumber ? companiesHouseNumber.trim() : null
  });

  // Log the edit action
  createAuditLog({
    adminId: req.session.user.id,
    adminName: req.session.user.name,
    action: 'edited',
    targetUserId: targetUser.id,
    targetUserName: targetUser.name,
    reason: auditReason,
    details: changes.length > 0 ? `Changed: ${changes.join('; ')}` : 'No fields changed',
    ipAddress: req.ip || 'unknown'
  });

  // Re-fetch the updated user to display
  const updatedUser = findUserById(targetUser.id);

  res.render('admin/user-edit', {
    title: `Edit: ${updatedUser.name}`,
    user: req.session.user,
    targetUser: updatedUser,
    activePage: 'users',
    reasons: AUDIT_REASONS,
    editReason: auditReason,
    success: 'User updated successfully. Audit log recorded.',
    error: null
  });
});

// ---------------------
// GET /admin/audit - Audit log viewer
// ---------------------
router.get('/audit', (req, res) => {
  const logs = getAllAuditLogs();
  res.render('admin/audit', {
    title: 'Audit Log',
    user: req.session.user,
    logs,
    activePage: 'audit'
  });
});

module.exports = router;
