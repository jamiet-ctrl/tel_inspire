/**
 * Customer Portal Routes
 * ======================
 * Protected routes for logged-in customers.
 * Shows welcome page and account details.
 */

const express = require('express');
const router = express.Router();
const { findUserById } = require('../models/database');

// ---------------------
// Middleware: require logged-in user
// ---------------------
function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  next();
}

// Apply auth middleware to all customer routes
router.use(requireAuth);

// ---------------------
// GET /customer - Customer welcome / dashboard
// ---------------------
router.get('/', (req, res) => {
  // Fetch fresh user data from database (in case admin has edited it)
  const user = findUserById(req.session.user.id);
  if (!user) {
    return res.redirect('/logout');
  }

  res.render('customer/dashboard', {
    title: 'My Account',
    user: {
      ...user,
      // Include session-tracked login info
      lastLoginTime: user.lastLoginTime,
      lastLoginIP: user.lastLoginIP,
      lastDevice: user.lastDevice
    }
  });
});

module.exports = router;
