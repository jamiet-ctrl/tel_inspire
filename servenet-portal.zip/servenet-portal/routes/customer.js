/**
 * Customer Routes v5 — MySQL async
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { findUserById, updateUserProfile, updateUserPassword, createAuditLog } = require('../models/database');

function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}
router.use(requireAuth);

router.get('/', async (req, res) => {
  const user = await findUserById(req.session.user.id);
  if (!user) return res.redirect('/logout');
  res.render('customer/dashboard', { title: 'My Account', user });
});

router.get('/settings', async (req, res) => {
  const user = await findUserById(req.session.user.id);
  res.render('customer/settings', {
    title: 'Settings', user, activePage: 'settings',
    success: null, error: null, tab: req.query.tab || 'profile'
  });
});

// Profile update — AUDIT LOGGED
router.post('/settings/profile', async (req, res) => {
  const { firstName, lastName, phone, addressLine1, addressLine2, city, postcode } = req.body;
  const user = await findUserById(req.session.user.id);

  if (!firstName?.trim() || !lastName?.trim()) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'First and last name are required.', tab: 'profile'
    });
  }

  const changes = [];
  if (firstName.trim() !== user.firstName) changes.push(`firstName: ${user.firstName} → ${firstName.trim()}`);
  if (lastName.trim() !== user.lastName) changes.push(`lastName: ${user.lastName} → ${lastName.trim()}`);
  if ((phone?.trim() || null) !== (user.phone || null)) changes.push(`phone changed`);
  if ((addressLine1?.trim() || null) !== (user.addressLine1 || null)) changes.push(`address1 changed`);
  if ((city?.trim() || null) !== (user.city || null)) changes.push(`city changed`);
  const newPostcode = postcode?.trim().toUpperCase() || null;
  if (newPostcode !== (user.postcode || null)) changes.push(`postcode changed`);

  await updateUserProfile(req.session.user.id, {
    firstName: firstName.trim(), lastName: lastName.trim(),
    phone: phone?.trim() || null, addressLine1: addressLine1?.trim() || null,
    addressLine2: addressLine2?.trim() || null, city: city?.trim() || null,
    postcode: newPostcode
  });

  await createAuditLog({
    adminId: user.id, adminName: `${user.firstName} ${user.lastName}`, adminEmail: user.email,
    action: 'self_profile_update', category: 'data_modification',
    targetUserId: user.id, targetUserName: `${user.firstName} ${user.lastName}`, targetUserEmail: user.email,
    reason: 'Self-service',
    details: changes.length > 0 ? `Customer updated own profile: ${changes.join('; ')}` : 'No changes made',
    ipAddress: req.ip || 'unknown', userAgent: req.get('User-Agent') || 'unknown'
  });

  req.session.user.name = `${firstName.trim()} ${lastName.trim()}`;
  const refreshed = await findUserById(req.session.user.id);
  res.render('customer/settings', {
    title: 'Settings', user: refreshed, activePage: 'settings',
    success: 'Profile updated.', error: null, tab: 'profile'
  });
});

// Password change — AUDIT LOGGED
router.post('/settings/password', async (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const user = await findUserById(req.session.user.id);

  if (!currentPassword || !newPassword || !confirmPassword) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'All password fields are required.', tab: 'password'
    });
  }
  if (!bcrypt.compareSync(currentPassword, user.password)) {
    await createAuditLog({
      adminId: user.id, adminName: `${user.firstName} ${user.lastName}`, adminEmail: user.email,
      action: 'self_password_failed', category: 'security',
      targetUserId: user.id, targetUserName: `${user.firstName} ${user.lastName}`, targetUserEmail: user.email,
      reason: 'Self-service',
      details: 'Customer attempted to change password but entered incorrect current password',
      ipAddress: req.ip || 'unknown', userAgent: req.get('User-Agent') || 'unknown'
    });
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'Current password is incorrect.', tab: 'password'
    });
  }
  if (newPassword.length < 8) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'New password must be at least 8 characters.', tab: 'password'
    });
  }
  if (newPassword !== confirmPassword) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'Passwords do not match.', tab: 'password'
    });
  }

  await updateUserPassword(user.id, bcrypt.hashSync(newPassword, 10));

  await createAuditLog({
    adminId: user.id, adminName: `${user.firstName} ${user.lastName}`, adminEmail: user.email,
    action: 'self_password_changed', category: 'security',
    targetUserId: user.id, targetUserName: `${user.firstName} ${user.lastName}`, targetUserEmail: user.email,
    reason: 'Self-service',
    details: 'Customer successfully changed their own password',
    ipAddress: req.ip || 'unknown', userAgent: req.get('User-Agent') || 'unknown'
  });

  const refreshed = await findUserById(req.session.user.id);
  res.render('customer/settings', {
    title: 'Settings', user: refreshed, activePage: 'settings',
    success: 'Password changed.', error: null, tab: 'password'
  });
});

module.exports = router;
