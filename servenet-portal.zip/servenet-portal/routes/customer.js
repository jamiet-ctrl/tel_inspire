/**
 * Customer Portal Routes
 * ======================
 * Shows welcome page and account details for logged-in customers.
 */

const express = require('express');
const router = express.Router();
const { findUserById } = require('../models/database');

function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

router.use(requireAuth);

router.get('/', (req, res) => {
  const user = findUserById(req.session.user.id);
  if (!user) return res.redirect('/logout');

  res.render('customer/dashboard', {
    title: 'My Account',
    user: user
  });
});

module.exports = router;
