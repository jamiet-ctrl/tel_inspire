/**
 * Database Model v5 — MySQL/MariaDB
 * ===================================
 * OFCOM-compliant customer portal database layer.
 * Uses mysql2/promise with connection pooling.
 *
 * Configure via environment variables:
 *   DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME
 */

const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

// ===========================
// Connection Pool
// ===========================

let pool;

function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.DB_HOST || '127.0.0.1',
      port: parseInt(process.env.DB_PORT) || 3306,
      user: process.env.DB_USER || 'servenet',
      password: process.env.DB_PASS || 'servenet',
      database: process.env.DB_NAME || 'servenet_portal',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      charset: 'utf8mb4'
    });
  }
  return pool;
}

// ===========================
// Schema
// ===========================

async function initDatabase() {
  // Tables are created by setup.sql — just verify connection
  const db = getPool();
  const [rows] = await db.execute('SELECT 1');
  console.log('[DB] MySQL connection verified.');
}

// ===========================
// Seed Data
// ===========================

async function seedDatabase() {
  const db = getPool();
  const [rows] = await db.execute('SELECT COUNT(*) as cnt FROM users');
  if (rows[0].cnt > 0) {
    console.log('[DB] Seed data already exists, skipping.');
    return;
  }

  const hash = bcrypt.hashSync('ServeNet01!', 10);

  const seedUsers = [
    ['Admin', 'User', 'admin@servenet.io', hash, 'admin', 0, null, null, 'CH65 1AA', 'ServeNet HQ, 10 Station Road', 'Ellesmere Port', '0151 000 0001', 0, null],
    ['John', 'Smith', 'customer@servenet.io', hash, 'customer', 0, null, null, 'CH65 2BB', '14 Mersey Road', 'Ellesmere Port', '07700 100001', 0, null],
    ['Jane', 'Doe', 'business@servenet.io', hash, 'customer', 1, 'Acme Trading Ltd', '12345678', 'CH1 3CC', 'Unit 5, Chester Business Park', 'Chester', '01244 500001', 0, null],
    ['Sarah', 'Johnson', 'sarah.j@servenet.io', hash, 'customer', 0, null, null, 'CH66 4DD', '8 Whitby Road', 'Ellesmere Port', '07700 100002', 1, 'Elderly customer, limited mobility. Prefers phone contact. Has a nominated representative: daughter Emily Johnson (07700 100099).'],
    ['Mike', 'Williams', 'mike@techsolutions.co.uk', hash, 'customer', 1, 'Tech Solutions Ltd', '87654321', 'CW1 5EE', '22 Technology Drive', 'Crewe', '01270 600001', 0, null],
    ['Emma', 'Brown', 'emma.b@servenet.io', hash, 'customer', 0, null, null, 'CH2 6FF', '3 Garden Lane', 'Chester', '07700 100003', 1, 'Mental health condition disclosed. May need extra time processing information. Agreed to receive communications in writing only.'],
    ['David', 'Taylor', 'david@taylormotors.co.uk', hash, 'customer', 1, 'Taylor Motors Ltd', '11223344', 'WA7 7GG', '1 Industrial Estate', 'Runcorn', '01928 700001', 0, null],
    ['Lisa', 'Wilson', 'lisa.w@servenet.io', hash, 'customer', 0, null, null, 'CH65 8HH', '29 Riverview Close', 'Ellesmere Port', '07700 100004', 0, null],
    ['Robert', 'Davies', 'rob@daviesaccounting.co.uk', hash, 'customer', 1, 'Davies Accounting Services', '55667788', 'CH3 9JJ', '15 High Street', 'Tarvin', '01829 800001', 0, null],
    ['Margaret', 'Hughes', 'margaret.h@servenet.io', hash, 'customer', 0, null, null, 'CH66 0KK', '7 Oak Avenue', 'Ellesmere Port', '0151 000 0010', 1, 'Registered sight impairment. Requires large print correspondence and accessible formats. Has power of attorney holder: son James Hughes.']
  ];

  const userSql = `INSERT INTO users (firstName, lastName, email, password, role, isBusiness, businessName,
    companiesHouseNumber, postcode, addressLine1, city, phone, isVulnerable, vulnerabilityNotes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

  for (const u of seedUsers) {
    await db.execute(userSql, u);
  }
  console.log('[DB] Seed accounts created (10 users).');

  const seedServices = [
    [2, 'broadband', 'Unlimited Fibre 80', 'SN-BB-100201', null, 'active', 34.99, null],
    [2, 'mobile', 'Essential Mobile Plan', 'SN-MOB-100202', '+447700100001', 'active', 12.99, null],
    [3, 'broadband', 'Business Fibre 300', 'SN-BB-200301', null, 'active', 59.99, 'Static IP allocated: 203.0.113.50'],
    [3, 'mobile', 'Business Mobile Unlimited', 'SN-MOB-200302', '+441244500001', 'active', 24.99, null],
    [3, 'hosting', 'Managed Web Hosting', 'SN-HOST-200303', null, 'active', 19.99, 'acmetrading.co.uk hosted'],
    [4, 'broadband', 'Essential Broadband 40', 'SN-BB-100401', null, 'active', 24.99, 'Vulnerable customer - ensure engineer visits are pre-arranged with daughter Emily'],
    [4, 'landline', 'Home Phone Basic', 'SN-LL-100402', null, 'active', 9.99, 'Primary contact method for this customer'],
    [5, 'broadband', 'Business Fibre 500', 'SN-BB-200501', null, 'active', 79.99, 'Leased line backup in place'],
    [5, 'mobile', 'Business Mobile Unlimited', 'SN-MOB-200502', '+441270600001', 'active', 24.99, null],
    [5, 'mobile', 'Business Mobile Unlimited', 'SN-MOB-200503', '+441270600002', 'active', 24.99, 'Second line - assigned to Operations Manager'],
    [5, 'domain', 'Domain Registration', 'SN-DOM-200504', null, 'active', 1.25, 'techsolutions.co.uk - auto-renew enabled'],
    [6, 'broadband', 'Unlimited Fibre 80', 'SN-BB-100601', null, 'active', 34.99, null],
    [6, 'mobile', 'Essential Mobile Plan', 'SN-MOB-100602', '+447700100003', 'suspended', 12.99, 'Suspended at customer request - reviewing in 30 days'],
    [7, 'broadband', 'Business Fibre 150', 'SN-BB-200701', null, 'active', 44.99, null],
    [8, 'broadband', 'Essential Broadband 40', 'SN-BB-100801', null, 'active', 24.99, null],
    [8, 'mobile', 'Unlimited Mobile Plan', 'SN-MOB-100802', '+447700100004', 'active', 19.99, null],
    [9, 'broadband', 'Business Fibre 300', 'SN-BB-200901', null, 'active', 59.99, null],
    [9, 'hosting', 'Business Email Hosting', 'SN-EMAIL-200902', null, 'active', 9.99, '10 mailboxes - @daviesaccounting.co.uk'],
    [10, 'broadband', 'Essential Broadband 40', 'SN-BB-101001', null, 'active', 24.99, 'Vulnerable customer - large print bills posted monthly'],
    [10, 'landline', 'Home Phone Inclusive', 'SN-LL-101002', null, 'active', 14.99, 'Includes free calls to UK landlines - primary contact method']
  ];

  const svcSql = `INSERT INTO services (userId, serviceType, serviceName, serviceRef, mobileNumber, status, monthlyCost, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

  for (const s of seedServices) {
    await db.execute(svcSql, s);
  }
  console.log('[DB] Seed services created.');
}

// ===========================
// User Queries
// ===========================

async function findUserByEmail(email) {
  const [rows] = await getPool().execute('SELECT * FROM users WHERE email = ?', [email]);
  return rows[0] || null;
}

async function findUserById(id) {
  const [rows] = await getPool().execute('SELECT * FROM users WHERE id = ?', [id]);
  return rows[0] || null;
}

async function getAllUsers() {
  const [rows] = await getPool().execute(`
    SELECT id, firstName, lastName, email, role, isBusiness, businessName,
      companiesHouseNumber, postcode, isVulnerable, accountStatus, lastLoginTime
    FROM users ORDER BY lastName ASC, firstName ASC
  `);
  return rows;
}

async function searchCustomers(query, filters = {}) {
  let sql = `
    SELECT id, firstName, lastName, email, role, isBusiness, businessName,
      companiesHouseNumber, postcode, isVulnerable, accountStatus, phone, lastLoginTime
    FROM users WHERE isBusiness = 0 AND role = 'customer'
  `;
  const params = [];

  if (query && query.trim()) {
    const q = `%${query.trim()}%`;
    sql += ` AND (
      CAST(id AS CHAR) LIKE ? OR
      firstName LIKE ? OR lastName LIKE ? OR
      CONCAT(firstName, ' ', lastName) LIKE ? OR
      email LIKE ? OR postcode LIKE ? OR phone LIKE ?
    )`;
    params.push(q, q, q, q, q, q, q);
  }
  if (filters.vulnerableOnly) sql += ' AND isVulnerable = 1';
  if (filters.postcode) {
    sql += ' AND postcode LIKE ?';
    params.push(`${filters.postcode.trim()}%`);
  }

  sql += ' ORDER BY lastName ASC, firstName ASC';
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

async function searchBusinessCustomers(query, filters = {}) {
  let sql = `
    SELECT id, firstName, lastName, email, role, isBusiness, businessName,
      companiesHouseNumber, postcode, isVulnerable, accountStatus, phone, lastLoginTime
    FROM users WHERE isBusiness = 1
  `;
  const params = [];

  if (query && query.trim()) {
    const q = `%${query.trim()}%`;
    sql += ` AND (
      CAST(id AS CHAR) LIKE ? OR
      firstName LIKE ? OR lastName LIKE ? OR
      CONCAT(firstName, ' ', lastName) LIKE ? OR
      email LIKE ? OR businessName LIKE ? OR
      companiesHouseNumber LIKE ? OR postcode LIKE ?
    )`;
    params.push(q, q, q, q, q, q, q, q);
  }
  if (filters.postcode) {
    sql += ' AND postcode LIKE ?';
    params.push(`${filters.postcode.trim()}%`);
  }

  sql += ' ORDER BY businessName ASC, lastName ASC';
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

async function updateLoginInfo(userId, ip, userAgent) {
  await getPool().execute(`
    UPDATE users SET lastLoginTime = NOW(), lastLoginIP = ?, lastDevice = ?,
      failedLoginAttempts = 0, updatedAt = NOW()
    WHERE id = ?
  `, [ip, userAgent, userId]);
}

async function updateUser(id, data) {
  await getPool().execute(`
    UPDATE users
    SET firstName = ?, lastName = ?, role = ?, isBusiness = ?,
      businessName = ?, companiesHouseNumber = ?, postcode = ?,
      addressLine1 = ?, addressLine2 = ?, city = ?, phone = ?,
      isVulnerable = ?, vulnerabilityNotes = ?, accountStatus = ?,
      updatedAt = NOW()
    WHERE id = ?
  `, [
    data.firstName, data.lastName, data.role, data.isBusiness ? 1 : 0,
    data.businessName || null, data.companiesHouseNumber || null,
    data.postcode || null, data.addressLine1 || null, data.addressLine2 || null,
    data.city || null, data.phone || null,
    data.isVulnerable ? 1 : 0, data.vulnerabilityNotes || null,
    data.accountStatus || 'active', id
  ]);
}

async function updateUserPassword(userId, hashedPassword) {
  await getPool().execute('UPDATE users SET password = ?, updatedAt = NOW() WHERE id = ?', [hashedPassword, userId]);
}

async function updateUserProfile(userId, data) {
  await getPool().execute(`
    UPDATE users SET firstName = ?, lastName = ?, phone = ?,
      addressLine1 = ?, addressLine2 = ?, city = ?, postcode = ?, updatedAt = NOW()
    WHERE id = ?
  `, [
    data.firstName, data.lastName, data.phone || null,
    data.addressLine1 || null, data.addressLine2 || null,
    data.city || null, data.postcode || null, userId
  ]);
}

// ===========================
// Login Attempt & Lockout
// ===========================

const MAX_LOGIN_ATTEMPTS = 3;
const LOCKOUT_DURATION_MINS = 30;

async function recordLoginAttempt(email, ip, userAgent, success, failureReason = null) {
  await getPool().execute(
    'INSERT INTO login_attempts (email, ipAddress, userAgent, success, failureReason) VALUES (?, ?, ?, ?, ?)',
    [email, ip, userAgent, success ? 1 : 0, failureReason]
  );
}

async function incrementFailedAttempts(userId) {
  const user = await findUserById(userId);
  const newCount = (user.failedLoginAttempts || 0) + 1;

  if (newCount >= MAX_LOGIN_ATTEMPTS) {
    await getPool().execute(
      "UPDATE users SET failedLoginAttempts = ?, accountStatus = 'locked', lockedAt = NOW(), updatedAt = NOW() WHERE id = ?",
      [newCount, userId]
    );
    return { locked: true, attempts: newCount };
  } else {
    await getPool().execute(
      'UPDATE users SET failedLoginAttempts = ?, updatedAt = NOW() WHERE id = ?',
      [newCount, userId]
    );
    return { locked: false, attempts: newCount, remaining: MAX_LOGIN_ATTEMPTS - newCount };
  }
}

async function isAccountLocked(user) {
  if (user.accountStatus !== 'locked') return false;
  if (user.lockedAt) {
    const lockedTime = new Date(user.lockedAt).getTime();
    const elapsed = (Date.now() - lockedTime) / 1000 / 60;
    if (elapsed >= LOCKOUT_DURATION_MINS) {
      await getPool().execute(
        "UPDATE users SET accountStatus = 'active', failedLoginAttempts = 0, lockedAt = NULL, updatedAt = NOW() WHERE id = ?",
        [user.id]
      );
      return false;
    }
  }
  return true;
}

async function unlockAccount(userId) {
  await getPool().execute(
    "UPDATE users SET accountStatus = 'active', failedLoginAttempts = 0, lockedAt = NULL, updatedAt = NOW() WHERE id = ?",
    [userId]
  );
}

async function getLoginAttempts(filters = {}) {
  let sql = 'SELECT * FROM login_attempts WHERE 1=1';
  const params = [];

  if (filters.email) {
    sql += ' AND email LIKE ?';
    params.push(`%${filters.email}%`);
  }
  if (filters.successOnly) sql += ' AND success = 1';
  if (filters.failedOnly) sql += ' AND success = 0';
  if (filters.after) {
    sql += ' AND timestamp >= ?';
    params.push(filters.after);
  }

  sql += ' ORDER BY timestamp DESC LIMIT 500';
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

// ===========================
// Audit Log Queries
// ===========================

async function createAuditLog(data) {
  await getPool().execute(`
    INSERT INTO audit_logs (adminId, adminName, adminEmail, action, category,
      targetUserId, targetUserName, targetUserEmail, reason, details,
      previousValues, newValues, ipAddress, userAgent)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    data.adminId, data.adminName, data.adminEmail || '',
    data.action, data.category || 'general',
    data.targetUserId || null, data.targetUserName || null, data.targetUserEmail || null,
    data.reason, data.details || null,
    data.previousValues || null, data.newValues || null,
    data.ipAddress || null, data.userAgent || null
  ]);
}

async function getAuditLogs(filters = {}, page = 1, perPage = 50) {
  let whereSql = ' WHERE 1=1';
  const params = [];

  if (filters.search) {
    const q = `%${filters.search}%`;
    whereSql += ` AND (
      adminName LIKE ? OR targetUserName LIKE ? OR
      targetUserEmail LIKE ? OR action LIKE ? OR
      reason LIKE ? OR details LIKE ? OR
      CAST(targetUserId AS CHAR) LIKE ?
    )`;
    params.push(q, q, q, q, q, q, q);
  }
  if (filters.action) { whereSql += ' AND action = ?'; params.push(filters.action); }
  if (filters.category) { whereSql += ' AND category = ?'; params.push(filters.category); }
  if (filters.reason) { whereSql += ' AND reason = ?'; params.push(filters.reason); }
  if (filters.adminId) { whereSql += ' AND adminId = ?'; params.push(filters.adminId); }
  if (filters.targetUserId) { whereSql += ' AND targetUserId = ?'; params.push(filters.targetUserId); }
  if (filters.dateFrom) { whereSql += ' AND timestamp >= ?'; params.push(filters.dateFrom); }
  if (filters.dateTo) { whereSql += ' AND timestamp <= ?'; params.push(filters.dateTo + ' 23:59:59'); }

  const [countRows] = await getPool().execute('SELECT COUNT(*) as cnt FROM audit_logs' + whereSql, params);
  const total = countRows[0].cnt;

  const offset = (page - 1) * perPage;
  const [rows] = await getPool().execute(
    'SELECT * FROM audit_logs' + whereSql + ' ORDER BY timestamp DESC LIMIT ? OFFSET ?',
    [...params, perPage, offset]
  );

  return { rows, total, page, perPage, totalPages: Math.ceil(total / perPage) || 1 };
}

async function getAuditLogsAll(filters = {}) {
  let sql = 'SELECT * FROM audit_logs WHERE 1=1';
  const params = [];

  if (filters.search) {
    const q = `%${filters.search}%`;
    sql += ` AND (adminName LIKE ? OR targetUserName LIKE ? OR targetUserEmail LIKE ? OR action LIKE ? OR reason LIKE ? OR details LIKE ? OR CAST(targetUserId AS CHAR) LIKE ?)`;
    params.push(q, q, q, q, q, q, q);
  }
  if (filters.action) { sql += ' AND action = ?'; params.push(filters.action); }
  if (filters.category) { sql += ' AND category = ?'; params.push(filters.category); }
  if (filters.reason) { sql += ' AND reason = ?'; params.push(filters.reason); }
  if (filters.targetUserId) { sql += ' AND targetUserId = ?'; params.push(filters.targetUserId); }
  if (filters.dateFrom) { sql += ' AND timestamp >= ?'; params.push(filters.dateFrom); }
  if (filters.dateTo) { sql += ' AND timestamp <= ?'; params.push(filters.dateTo + ' 23:59:59'); }

  sql += ' ORDER BY timestamp DESC';
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

async function getAuditStats() {
  const db = getPool();
  const today = new Date().toISOString().split('T')[0];
  const [[{cnt: totalLogs}]] = await db.execute('SELECT COUNT(*) as cnt FROM audit_logs');
  const [[{cnt: todayLogs}]] = await db.execute('SELECT COUNT(*) as cnt FROM audit_logs WHERE timestamp >= ?', [today]);
  const [[{cnt: uniqueAdmins}]] = await db.execute('SELECT COUNT(DISTINCT adminId) as cnt FROM audit_logs WHERE timestamp >= ?', [today]);
  const [[{cnt: recentEdits}]] = await db.execute("SELECT COUNT(*) as cnt FROM audit_logs WHERE action = 'edited' AND timestamp >= ?", [today]);
  const [[{cnt: failedLogins}]] = await db.execute('SELECT COUNT(*) as cnt FROM login_attempts WHERE success = 0 AND timestamp >= ?', [today]);
  const [[{cnt: lockedAccounts}]] = await db.execute("SELECT COUNT(*) as cnt FROM users WHERE accountStatus = 'locked'");
  return { totalLogs, todayLogs, uniqueAdmins, recentEdits, failedLogins, lockedAccounts };
}

async function autocompleteUsers(query) {
  if (!query || query.trim().length < 1) return [];
  const q = `%${query.trim()}%`;
  const [rows] = await getPool().execute(`
    SELECT id, firstName, lastName, email, businessName, isBusiness
    FROM users
    WHERE firstName LIKE ? OR lastName LIKE ? OR
      CONCAT(firstName, ' ', lastName) LIKE ? OR
      email LIKE ? OR businessName LIKE ? OR
      CAST(id AS CHAR) LIKE ?
    ORDER BY lastName ASC LIMIT 10
  `, [q, q, q, q, q, q]);
  return rows;
}

// ===========================
// Services Queries
// ===========================

async function getServicesForUser(userId) {
  const [rows] = await getPool().execute(
    'SELECT * FROM services WHERE userId = ? ORDER BY status ASC, serviceType ASC',
    [userId]
  );
  return rows;
}

// ===========================
// Notification Queries
// ===========================

async function createNotification({ type, title, message, targetAdminId, relatedUserId }) {
  await getPool().execute(
    'INSERT INTO notifications (type, title, message, targetAdminId, relatedUserId) VALUES (?, ?, ?, ?, ?)',
    [type, title, message, targetAdminId || null, relatedUserId || null]
  );
}

async function getUnreadNotifications(adminId) {
  const [rows] = await getPool().execute(
    'SELECT * FROM notifications WHERE (targetAdminId IS NULL OR targetAdminId = ?) AND isRead = 0 ORDER BY createdAt DESC LIMIT 50',
    [adminId]
  );
  return rows;
}

async function getAllNotifications(adminId) {
  const [rows] = await getPool().execute(
    'SELECT * FROM notifications WHERE (targetAdminId IS NULL OR targetAdminId = ?) ORDER BY createdAt DESC LIMIT 100',
    [adminId]
  );
  return rows;
}

async function markNotificationRead(id) {
  await getPool().execute('UPDATE notifications SET isRead = 1 WHERE id = ?', [id]);
}

async function markAllNotificationsRead(adminId) {
  await getPool().execute(
    'UPDATE notifications SET isRead = 1 WHERE (targetAdminId IS NULL OR targetAdminId = ?) AND isRead = 0',
    [adminId]
  );
}

// ===========================
// Gravatar Helper
// ===========================

function getGravatarUrl(email, size = 40) {
  const hash = crypto.createHash('md5').update(email.trim().toLowerCase()).digest('hex');
  return `https://www.gravatar.com/avatar/${hash}?s=${size}&d=mp`;
}

// ===========================
// Exports
// ===========================

module.exports = {
  getPool, initDatabase, seedDatabase,
  findUserByEmail, findUserById, getAllUsers,
  searchCustomers, searchBusinessCustomers,
  updateLoginInfo, updateUser, updateUserPassword, updateUserProfile,
  recordLoginAttempt, incrementFailedAttempts, isAccountLocked, unlockAccount, getLoginAttempts,
  createAuditLog, getAuditLogs, getAuditLogsAll, getAuditStats, autocompleteUsers,
  getServicesForUser,
  createNotification, getUnreadNotifications, getAllNotifications, markNotificationRead, markAllNotificationsRead,
  getGravatarUrl,
  MAX_LOGIN_ATTEMPTS, LOCKOUT_DURATION_MINS
};
