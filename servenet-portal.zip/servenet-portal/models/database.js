/**
 * Database Model v2
 * ==================
 * SQLite database with full OFCOM compliance features:
 * - Users with first/last name, postcode, vulnerability flag
 * - Business accounts with Companies House tracking
 * - Failed login attempt logging and account lockout (3 attempts)
 * - Comprehensive audit logging with full detail retention
 * - Admin session timeout tracking
 */

const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'database', 'servenet.db');
let db;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
  }
  return db;
}

// ===========================
// Schema
// ===========================

function initDatabase() {
  const conn = getDb();

  // Users table - split name, added postcode, vulnerability, lockout fields
  conn.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      firstName TEXT NOT NULL,
      lastName TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'customer',
      isBusiness INTEGER NOT NULL DEFAULT 0,
      businessName TEXT DEFAULT NULL,
      companiesHouseNumber TEXT DEFAULT NULL,
      postcode TEXT DEFAULT NULL,
      addressLine1 TEXT DEFAULT NULL,
      addressLine2 TEXT DEFAULT NULL,
      city TEXT DEFAULT NULL,
      phone TEXT DEFAULT NULL,
      isVulnerable INTEGER NOT NULL DEFAULT 0,
      vulnerabilityNotes TEXT DEFAULT NULL,
      accountStatus TEXT NOT NULL DEFAULT 'active',
      failedLoginAttempts INTEGER NOT NULL DEFAULT 0,
      lockedAt TEXT DEFAULT NULL,
      lastLoginTime TEXT DEFAULT NULL,
      lastLoginIP TEXT DEFAULT NULL,
      lastDevice TEXT DEFAULT NULL,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    )
  `);

  // Audit log table - expanded with full detail storage
  conn.exec(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      adminId INTEGER NOT NULL,
      adminName TEXT NOT NULL,
      adminEmail TEXT NOT NULL,
      action TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'general',
      targetUserId INTEGER DEFAULT NULL,
      targetUserName TEXT DEFAULT NULL,
      targetUserEmail TEXT DEFAULT NULL,
      reason TEXT NOT NULL,
      details TEXT DEFAULT NULL,
      previousValues TEXT DEFAULT NULL,
      newValues TEXT DEFAULT NULL,
      ipAddress TEXT DEFAULT NULL,
      userAgent TEXT DEFAULT NULL,
      timestamp TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (adminId) REFERENCES users(id)
    )
  `);

  // Failed login attempts log - separate table for security auditing
  conn.exec(`
    CREATE TABLE IF NOT EXISTS login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      ipAddress TEXT DEFAULT NULL,
      userAgent TEXT DEFAULT NULL,
      success INTEGER NOT NULL DEFAULT 0,
      failureReason TEXT DEFAULT NULL,
      timestamp TEXT DEFAULT (datetime('now'))
    )
  `);

  // Admin session activity tracking
  conn.exec(`
    CREATE TABLE IF NOT EXISTS admin_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      adminId INTEGER NOT NULL,
      sessionId TEXT NOT NULL,
      loginTime TEXT DEFAULT (datetime('now')),
      lastActivity TEXT DEFAULT (datetime('now')),
      logoutTime TEXT DEFAULT NULL,
      ipAddress TEXT DEFAULT NULL,
      isActive INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (adminId) REFERENCES users(id)
    )
  `);

  // Customer services table
  conn.exec(`
    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      serviceType TEXT NOT NULL,
      serviceName TEXT NOT NULL,
      serviceRef TEXT DEFAULT NULL,
      mobileNumber TEXT DEFAULT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      startDate TEXT DEFAULT (datetime('now')),
      monthlyCost REAL DEFAULT 0,
      notes TEXT DEFAULT NULL,
      FOREIGN KEY (userId) REFERENCES users(id)
    )
  `);

  // Admin notifications table
  conn.exec(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      targetAdminId INTEGER DEFAULT NULL,
      relatedUserId INTEGER DEFAULT NULL,
      isRead INTEGER NOT NULL DEFAULT 0,
      createdAt TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (targetAdminId) REFERENCES users(id)
    )
  `);

  console.log('[DB] Database initialised successfully.');
}

// ===========================
// Seed Data
// ===========================

function seedDatabase() {
  const conn = getDb();

  const count = conn.prepare('SELECT COUNT(*) as cnt FROM users').get();
  if (count.cnt > 0) {
    console.log('[DB] Seed data already exists, skipping.');
    return;
  }

  const hash = bcrypt.hashSync('ServeNet01!', 10);

  const insert = conn.prepare(`
    INSERT INTO users (firstName, lastName, email, password, role, isBusiness, businessName,
      companiesHouseNumber, postcode, addressLine1, city, phone, isVulnerable, vulnerabilityNotes)
    VALUES (@firstName, @lastName, @email, @password, @role, @isBusiness, @businessName,
      @companiesHouseNumber, @postcode, @addressLine1, @city, @phone, @isVulnerable, @vulnerabilityNotes)
  `);

  const seedUsers = [
    {
      firstName: 'Admin', lastName: 'User', email: 'admin@servenet.io',
      password: hash, role: 'admin', isBusiness: 0, businessName: null,
      companiesHouseNumber: null, postcode: 'CH65 1AA', addressLine1: 'ServeNet HQ, 10 Station Road',
      city: 'Ellesmere Port', phone: '0151 000 0001', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'John', lastName: 'Smith', email: 'customer@servenet.io',
      password: hash, role: 'customer', isBusiness: 0, businessName: null,
      companiesHouseNumber: null, postcode: 'CH65 2BB', addressLine1: '14 Mersey Road',
      city: 'Ellesmere Port', phone: '07700 100001', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'Jane', lastName: 'Doe', email: 'business@servenet.io',
      password: hash, role: 'customer', isBusiness: 1, businessName: 'Acme Trading Ltd',
      companiesHouseNumber: '12345678', postcode: 'CH1 3CC', addressLine1: 'Unit 5, Chester Business Park',
      city: 'Chester', phone: '01244 500001', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'Sarah', lastName: 'Johnson', email: 'sarah.j@servenet.io',
      password: hash, role: 'customer', isBusiness: 0, businessName: null,
      companiesHouseNumber: null, postcode: 'CH66 4DD', addressLine1: '8 Whitby Road',
      city: 'Ellesmere Port', phone: '07700 100002', isVulnerable: 1,
      vulnerabilityNotes: 'Elderly customer, limited mobility. Prefers phone contact. Has a nominated representative: daughter Emily Johnson (07700 100099).'
    },
    {
      firstName: 'Mike', lastName: 'Williams', email: 'mike@techsolutions.co.uk',
      password: hash, role: 'customer', isBusiness: 1, businessName: 'Tech Solutions Ltd',
      companiesHouseNumber: '87654321', postcode: 'CW1 5EE', addressLine1: '22 Technology Drive',
      city: 'Crewe', phone: '01270 600001', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'Emma', lastName: 'Brown', email: 'emma.b@servenet.io',
      password: hash, role: 'customer', isBusiness: 0, businessName: null,
      companiesHouseNumber: null, postcode: 'CH2 6FF', addressLine1: '3 Garden Lane',
      city: 'Chester', phone: '07700 100003', isVulnerable: 1,
      vulnerabilityNotes: 'Mental health condition disclosed. May need extra time processing information. Agreed to receive communications in writing only.'
    },
    {
      firstName: 'David', lastName: 'Taylor', email: 'david@taylormotors.co.uk',
      password: hash, role: 'customer', isBusiness: 1, businessName: 'Taylor Motors Ltd',
      companiesHouseNumber: '11223344', postcode: 'WA7 7GG', addressLine1: '1 Industrial Estate',
      city: 'Runcorn', phone: '01928 700001', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'Lisa', lastName: 'Wilson', email: 'lisa.w@servenet.io',
      password: hash, role: 'customer', isBusiness: 0, businessName: null,
      companiesHouseNumber: null, postcode: 'CH65 8HH', addressLine1: '29 Riverview Close',
      city: 'Ellesmere Port', phone: '07700 100004', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'Robert', lastName: 'Davies', email: 'rob@daviesaccounting.co.uk',
      password: hash, role: 'customer', isBusiness: 1, businessName: 'Davies Accounting Services',
      companiesHouseNumber: '55667788', postcode: 'CH3 9JJ', addressLine1: '15 High Street',
      city: 'Tarvin', phone: '01829 800001', isVulnerable: 0, vulnerabilityNotes: null
    },
    {
      firstName: 'Margaret', lastName: 'Hughes', email: 'margaret.h@servenet.io',
      password: hash, role: 'customer', isBusiness: 0, businessName: null,
      companiesHouseNumber: null, postcode: 'CH66 0KK', addressLine1: '7 Oak Avenue',
      city: 'Ellesmere Port', phone: '0151 000 0010', isVulnerable: 1,
      vulnerabilityNotes: 'Registered sight impairment. Requires large print correspondence and accessible formats. Has power of attorney holder: son James Hughes.'
    }
  ];

  const insertMany = conn.transaction((users) => {
    for (const u of users) insert.run(u);
  });
  insertMany(seedUsers);

  console.log('[DB] Seed accounts created (10 users).');

  // Seed services for demo customers
  const insertService = conn.prepare(`
    INSERT INTO services (userId, serviceType, serviceName, serviceRef, mobileNumber, status, monthlyCost, notes)
    VALUES (@userId, @serviceType, @serviceName, @serviceRef, @mobileNumber, @status, @monthlyCost, @notes)
  `);

  const seedServices = [
    // John Smith (id 2)
    { userId: 2, serviceType: 'broadband', serviceName: 'Unlimited Fibre 80', serviceRef: 'SN-BB-100201', mobileNumber: null, status: 'active', monthlyCost: 34.99, notes: null },
    { userId: 2, serviceType: 'mobile', serviceName: 'Essential Mobile Plan', serviceRef: 'SN-MOB-100202', mobileNumber: '+447700100001', status: 'active', monthlyCost: 12.99, notes: null },
    // Jane Doe / Acme Trading (id 3)
    { userId: 3, serviceType: 'broadband', serviceName: 'Business Fibre 300', serviceRef: 'SN-BB-200301', mobileNumber: null, status: 'active', monthlyCost: 59.99, notes: 'Static IP allocated: 203.0.113.50' },
    { userId: 3, serviceType: 'mobile', serviceName: 'Business Mobile Unlimited', serviceRef: 'SN-MOB-200302', mobileNumber: '+441244500001', status: 'active', monthlyCost: 24.99, notes: null },
    { userId: 3, serviceType: 'hosting', serviceName: 'Managed Web Hosting', serviceRef: 'SN-HOST-200303', mobileNumber: null, status: 'active', monthlyCost: 19.99, notes: 'acmetrading.co.uk hosted' },
    // Sarah Johnson (id 4)
    { userId: 4, serviceType: 'broadband', serviceName: 'Essential Broadband 40', serviceRef: 'SN-BB-100401', mobileNumber: null, status: 'active', monthlyCost: 24.99, notes: 'Vulnerable customer - ensure engineer visits are pre-arranged with daughter Emily' },
    { userId: 4, serviceType: 'landline', serviceName: 'Home Phone Basic', serviceRef: 'SN-LL-100402', mobileNumber: null, status: 'active', monthlyCost: 9.99, notes: 'Primary contact method for this customer' },
    // Mike Williams / Tech Solutions (id 5)
    { userId: 5, serviceType: 'broadband', serviceName: 'Business Fibre 500', serviceRef: 'SN-BB-200501', mobileNumber: null, status: 'active', monthlyCost: 79.99, notes: 'Leased line backup in place' },
    { userId: 5, serviceType: 'mobile', serviceName: 'Business Mobile Unlimited', serviceRef: 'SN-MOB-200502', mobileNumber: '+441270600001', status: 'active', monthlyCost: 24.99, notes: null },
    { userId: 5, serviceType: 'mobile', serviceName: 'Business Mobile Unlimited', serviceRef: 'SN-MOB-200503', mobileNumber: '+441270600002', status: 'active', monthlyCost: 24.99, notes: 'Second line - assigned to Operations Manager' },
    { userId: 5, serviceType: 'domain', serviceName: 'Domain Registration', serviceRef: 'SN-DOM-200504', mobileNumber: null, status: 'active', monthlyCost: 1.25, notes: 'techsolutions.co.uk - auto-renew enabled' },
    // Emma Brown (id 6)
    { userId: 6, serviceType: 'broadband', serviceName: 'Unlimited Fibre 80', serviceRef: 'SN-BB-100601', mobileNumber: null, status: 'active', monthlyCost: 34.99, notes: null },
    { userId: 6, serviceType: 'mobile', serviceName: 'Essential Mobile Plan', serviceRef: 'SN-MOB-100602', mobileNumber: '+447700100003', status: 'suspended', monthlyCost: 12.99, notes: 'Suspended at customer request - reviewing in 30 days' },
    // David Taylor / Taylor Motors (id 7)
    { userId: 7, serviceType: 'broadband', serviceName: 'Business Fibre 150', serviceRef: 'SN-BB-200701', mobileNumber: null, status: 'active', monthlyCost: 44.99, notes: null },
    // Lisa Wilson (id 8)
    { userId: 8, serviceType: 'broadband', serviceName: 'Essential Broadband 40', serviceRef: 'SN-BB-100801', mobileNumber: null, status: 'active', monthlyCost: 24.99, notes: null },
    { userId: 8, serviceType: 'mobile', serviceName: 'Unlimited Mobile Plan', serviceRef: 'SN-MOB-100802', mobileNumber: '+447700100004', status: 'active', monthlyCost: 19.99, notes: null },
    // Robert Davies / Davies Accounting (id 9)
    { userId: 9, serviceType: 'broadband', serviceName: 'Business Fibre 300', serviceRef: 'SN-BB-200901', mobileNumber: null, status: 'active', monthlyCost: 59.99, notes: null },
    { userId: 9, serviceType: 'hosting', serviceName: 'Business Email Hosting', serviceRef: 'SN-EMAIL-200902', mobileNumber: null, status: 'active', monthlyCost: 9.99, notes: '10 mailboxes - @daviesaccounting.co.uk' },
    // Margaret Hughes (id 10)
    { userId: 10, serviceType: 'broadband', serviceName: 'Essential Broadband 40', serviceRef: 'SN-BB-101001', mobileNumber: null, status: 'active', monthlyCost: 24.99, notes: 'Vulnerable customer - large print bills posted monthly' },
    { userId: 10, serviceType: 'landline', serviceName: 'Home Phone Inclusive', serviceRef: 'SN-LL-101002', mobileNumber: null, status: 'active', monthlyCost: 14.99, notes: 'Includes free calls to UK landlines - primary contact method' }
  ];

  const insertManyServices = conn.transaction((svcs) => {
    for (const s of svcs) insertService.run(s);
  });
  insertManyServices(seedServices);

  console.log('[DB] Seed services created.');
}

// ===========================
// User Queries
// ===========================

function findUserByEmail(email) {
  return getDb().prepare('SELECT * FROM users WHERE email = ?').get(email);
}

function findUserById(id) {
  return getDb().prepare('SELECT * FROM users WHERE id = ?').get(id);
}

function getAllUsers() {
  return getDb().prepare(`
    SELECT id, firstName, lastName, email, role, isBusiness, businessName,
      companiesHouseNumber, postcode, isVulnerable, accountStatus, lastLoginTime
    FROM users ORDER BY lastName ASC, firstName ASC
  `).all();
}

/**
 * Search residential customers (non-business)
 * Searches across: ID, name, email, postcode
 */
function searchCustomers(query, filters = {}) {
  let sql = `
    SELECT id, firstName, lastName, email, role, isBusiness, businessName,
      companiesHouseNumber, postcode, isVulnerable, accountStatus, phone, lastLoginTime
    FROM users WHERE isBusiness = 0 AND role = 'customer'
  `;
  const params = [];

  if (query && query.trim()) {
    const q = `%${query.trim()}%`;
    sql += ` AND (
      CAST(id AS TEXT) LIKE ? OR
      firstName LIKE ? OR lastName LIKE ? OR
      (firstName || ' ' || lastName) LIKE ? OR
      email LIKE ? OR postcode LIKE ? OR phone LIKE ?
    )`;
    params.push(q, q, q, q, q, q, q);
  }

  if (filters.vulnerableOnly) {
    sql += ` AND isVulnerable = 1`;
  }
  if (filters.postcode) {
    sql += ` AND postcode LIKE ?`;
    params.push(`${filters.postcode.trim()}%`);
  }

  sql += ` ORDER BY lastName ASC, firstName ASC`;
  return getDb().prepare(sql).all(...params);
}

/**
 * Search business customers
 * Searches across: ID, name, email, business name, companies house number, postcode
 */
function searchBusinessCustomers(query, filters = {}) {
  let sql = `
    SELECT id, firstName, lastName, email, role, isBusiness, businessName,
      companiesHouseNumber, postcode, isVulnerable, accountStatus, phone, lastLoginTime
    FROM users WHERE isBusiness = 1
  `;
  const params = [];

  if (query && query.trim()) {
    const q = `%${query.trim()}%`;
    sql += ` AND (
      CAST(id AS TEXT) LIKE ? OR
      firstName LIKE ? OR lastName LIKE ? OR
      (firstName || ' ' || lastName) LIKE ? OR
      email LIKE ? OR businessName LIKE ? OR
      companiesHouseNumber LIKE ? OR postcode LIKE ?
    )`;
    params.push(q, q, q, q, q, q, q, q);
  }

  if (filters.postcode) {
    sql += ` AND postcode LIKE ?`;
    params.push(`${filters.postcode.trim()}%`);
  }

  sql += ` ORDER BY businessName ASC, lastName ASC`;
  return getDb().prepare(sql).all(...params);
}

function updateLoginInfo(userId, ip, userAgent) {
  const now = new Date().toISOString();
  getDb().prepare(`
    UPDATE users SET lastLoginTime = ?, lastLoginIP = ?, lastDevice = ?,
      failedLoginAttempts = 0, updatedAt = datetime('now')
    WHERE id = ?
  `).run(now, ip, userAgent, userId);
}

function updateUser(id, data) {
  getDb().prepare(`
    UPDATE users
    SET firstName = ?, lastName = ?, role = ?, isBusiness = ?,
      businessName = ?, companiesHouseNumber = ?, postcode = ?,
      addressLine1 = ?, addressLine2 = ?, city = ?, phone = ?,
      isVulnerable = ?, vulnerabilityNotes = ?, accountStatus = ?,
      updatedAt = datetime('now')
    WHERE id = ?
  `).run(
    data.firstName, data.lastName, data.role, data.isBusiness ? 1 : 0,
    data.businessName || null, data.companiesHouseNumber || null,
    data.postcode || null, data.addressLine1 || null, data.addressLine2 || null,
    data.city || null, data.phone || null,
    data.isVulnerable ? 1 : 0, data.vulnerabilityNotes || null,
    data.accountStatus || 'active', id
  );
}

// ===========================
// Login Attempt & Lockout
// ===========================

const MAX_LOGIN_ATTEMPTS = 3;
const LOCKOUT_DURATION_MINS = 30;

function recordLoginAttempt(email, ip, userAgent, success, failureReason = null) {
  getDb().prepare(`
    INSERT INTO login_attempts (email, ipAddress, userAgent, success, failureReason)
    VALUES (?, ?, ?, ?, ?)
  `).run(email, ip, userAgent, success ? 1 : 0, failureReason);
}

function incrementFailedAttempts(userId) {
  const user = findUserById(userId);
  const newCount = (user.failedLoginAttempts || 0) + 1;

  if (newCount >= MAX_LOGIN_ATTEMPTS) {
    // Lock the account
    getDb().prepare(`
      UPDATE users SET failedLoginAttempts = ?, accountStatus = 'locked',
        lockedAt = datetime('now'), updatedAt = datetime('now')
      WHERE id = ?
    `).run(newCount, userId);
    return { locked: true, attempts: newCount };
  } else {
    getDb().prepare(`
      UPDATE users SET failedLoginAttempts = ?, updatedAt = datetime('now') WHERE id = ?
    `).run(newCount, userId);
    return { locked: false, attempts: newCount, remaining: MAX_LOGIN_ATTEMPTS - newCount };
  }
}

function isAccountLocked(user) {
  if (user.accountStatus !== 'locked') return false;
  // Check if lockout has expired
  if (user.lockedAt) {
    const lockedTime = new Date(user.lockedAt).getTime();
    const now = Date.now();
    const elapsed = (now - lockedTime) / 1000 / 60;
    if (elapsed >= LOCKOUT_DURATION_MINS) {
      // Auto-unlock
      getDb().prepare(`
        UPDATE users SET accountStatus = 'active', failedLoginAttempts = 0,
          lockedAt = NULL, updatedAt = datetime('now')
        WHERE id = ?
      `).run(user.id);
      return false;
    }
  }
  return true;
}

function unlockAccount(userId) {
  getDb().prepare(`
    UPDATE users SET accountStatus = 'active', failedLoginAttempts = 0,
      lockedAt = NULL, updatedAt = datetime('now')
    WHERE id = ?
  `).run(userId);
}

function getLoginAttempts(filters = {}) {
  let sql = 'SELECT * FROM login_attempts WHERE 1=1';
  const params = [];

  if (filters.email) {
    sql += ' AND email LIKE ?';
    params.push(`%${filters.email}%`);
  }
  if (filters.successOnly) sql += ' AND success = 1';
  if (filters.failedOnly) sql += ' AND success = 0';
  if (filters.after) {
    sql += ' AND timestamp >= ?';
    params.push(filters.after);
  }

  sql += ' ORDER BY timestamp DESC LIMIT 500';
  return getDb().prepare(sql).all(...params);
}

// ===========================
// Audit Log Queries
// ===========================

function createAuditLog(data) {
  getDb().prepare(`
    INSERT INTO audit_logs (adminId, adminName, adminEmail, action, category,
      targetUserId, targetUserName, targetUserEmail, reason, details,
      previousValues, newValues, ipAddress, userAgent)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    data.adminId, data.adminName, data.adminEmail || '',
    data.action, data.category || 'general',
    data.targetUserId || null, data.targetUserName || null, data.targetUserEmail || null,
    data.reason, data.details || null,
    data.previousValues || null, data.newValues || null,
    data.ipAddress || null, data.userAgent || null
  );
}

function getAuditLogs(filters = {}) {
  let sql = 'SELECT * FROM audit_logs WHERE 1=1';
  const params = [];

  if (filters.search) {
    const q = `%${filters.search}%`;
    sql += ` AND (
      adminName LIKE ? OR targetUserName LIKE ? OR
      targetUserEmail LIKE ? OR action LIKE ? OR
      reason LIKE ? OR details LIKE ? OR
      CAST(targetUserId AS TEXT) LIKE ?
    )`;
    params.push(q, q, q, q, q, q, q);
  }
  if (filters.action) {
    sql += ' AND action = ?';
    params.push(filters.action);
  }
  if (filters.category) {
    sql += ' AND category = ?';
    params.push(filters.category);
  }
  if (filters.reason) {
    sql += ' AND reason = ?';
    params.push(filters.reason);
  }
  if (filters.adminId) {
    sql += ' AND adminId = ?';
    params.push(filters.adminId);
  }
  if (filters.dateFrom) {
    sql += ' AND timestamp >= ?';
    params.push(filters.dateFrom);
  }
  if (filters.dateTo) {
    sql += ' AND timestamp <= ?';
    params.push(filters.dateTo + ' 23:59:59');
  }

  sql += ' ORDER BY timestamp DESC LIMIT 1000';
  return getDb().prepare(sql).all(...params);
}

function getAuditStats() {
  const conn = getDb();
  const today = new Date().toISOString().split('T')[0];
  return {
    totalLogs: conn.prepare('SELECT COUNT(*) as cnt FROM audit_logs').get().cnt,
    todayLogs: conn.prepare('SELECT COUNT(*) as cnt FROM audit_logs WHERE timestamp >= ?').get(today).cnt,
    uniqueAdmins: conn.prepare('SELECT COUNT(DISTINCT adminId) as cnt FROM audit_logs WHERE timestamp >= ?').get(today).cnt,
    recentEdits: conn.prepare("SELECT COUNT(*) as cnt FROM audit_logs WHERE action = 'edited' AND timestamp >= ?").get(today).cnt,
    failedLogins: conn.prepare('SELECT COUNT(*) as cnt FROM login_attempts WHERE success = 0 AND timestamp >= ?').get(today).cnt,
    lockedAccounts: conn.prepare("SELECT COUNT(*) as cnt FROM users WHERE accountStatus = 'locked'").get().cnt
  };
}

// ===========================
// Services Queries
// ===========================

function getServicesForUser(userId) {
  return getDb().prepare(`
    SELECT * FROM services WHERE userId = ? ORDER BY status ASC, serviceType ASC
  `).all(userId);
}

// ===========================
// Notification Queries
// ===========================

function createNotification({ type, title, message, targetAdminId, relatedUserId }) {
  getDb().prepare(`
    INSERT INTO notifications (type, title, message, targetAdminId, relatedUserId)
    VALUES (?, ?, ?, ?, ?)
  `).run(type, title, message, targetAdminId || null, relatedUserId || null);
}

function getUnreadNotifications(adminId) {
  return getDb().prepare(`
    SELECT * FROM notifications
    WHERE (targetAdminId IS NULL OR targetAdminId = ?) AND isRead = 0
    ORDER BY createdAt DESC LIMIT 50
  `).all(adminId);
}

function getAllNotifications(adminId) {
  return getDb().prepare(`
    SELECT * FROM notifications
    WHERE (targetAdminId IS NULL OR targetAdminId = ?)
    ORDER BY createdAt DESC LIMIT 100
  `).all(adminId);
}

function markNotificationRead(id) {
  getDb().prepare('UPDATE notifications SET isRead = 1 WHERE id = ?').run(id);
}

function markAllNotificationsRead(adminId) {
  getDb().prepare(`
    UPDATE notifications SET isRead = 1
    WHERE (targetAdminId IS NULL OR targetAdminId = ?) AND isRead = 0
  `).run(adminId);
}

// ===========================
// Gravatar Helper
// ===========================

const crypto = require('crypto');

function getGravatarUrl(email, size = 40) {
  const hash = crypto.createHash('md5').update(email.trim().toLowerCase()).digest('hex');
  return `https://www.gravatar.com/avatar/${hash}?s=${size}&d=mp`;
}

// ===========================
// Exports
// ===========================

module.exports = {
  getDb, initDatabase, seedDatabase,
  findUserByEmail, findUserById, getAllUsers,
  searchCustomers, searchBusinessCustomers,
  updateLoginInfo, updateUser,
  recordLoginAttempt, incrementFailedAttempts, isAccountLocked, unlockAccount, getLoginAttempts,
  createAuditLog, getAuditLogs, getAuditStats,
  getServicesForUser,
  createNotification, getUnreadNotifications, getAllNotifications, markNotificationRead, markAllNotificationsRead,
  getGravatarUrl,
  MAX_LOGIN_ATTEMPTS, LOCKOUT_DURATION_MINS
};
