/**
 * Database Model
 * ==============
 * Uses better-sqlite3 for synchronous SQLite access.
 * Handles schema creation, seed data, and all query helpers.
 */

const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

// Store the database file in the /database directory
const DB_PATH = path.join(__dirname, '..', 'database', 'servenet.db');
let db;

/**
 * Get or create the database connection (singleton)
 */
function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    // Enable WAL mode for better concurrent read performance
    db.pragma('journal_mode = WAL');
  }
  return db;
}

// ===========================
// Schema Initialisation
// ===========================

function initDatabase() {
  const conn = getDb();

  // Users table
  conn.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'customer',
      isBusiness INTEGER NOT NULL DEFAULT 0,
      businessName TEXT DEFAULT NULL,
      companiesHouseNumber TEXT DEFAULT NULL,
      lastLoginTime TEXT DEFAULT NULL,
      lastLoginIP TEXT DEFAULT NULL,
      lastDevice TEXT DEFAULT NULL,
      createdAt TEXT DEFAULT (datetime('now'))
    )
  `);

  // Audit log table - stores every admin action for OFCOM compliance
  conn.exec(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      adminId INTEGER NOT NULL,
      adminName TEXT NOT NULL,
      action TEXT NOT NULL,
      targetUserId INTEGER NOT NULL,
      targetUserName TEXT NOT NULL,
      reason TEXT NOT NULL,
      details TEXT DEFAULT NULL,
      ipAddress TEXT DEFAULT NULL,
      timestamp TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (adminId) REFERENCES users(id),
      FOREIGN KEY (targetUserId) REFERENCES users(id)
    )
  `);

  console.log('[DB] Database initialised successfully.');
}

// ===========================
// Seed Data
// ===========================

function seedDatabase() {
  const conn = getDb();

  // Only seed if no users exist yet
  const count = conn.prepare('SELECT COUNT(*) as cnt FROM users').get();
  if (count.cnt > 0) {
    console.log('[DB] Seed data already exists, skipping.');
    return;
  }

  const hashedPassword = bcrypt.hashSync('ServeNet01!', 10);

  const insertUser = conn.prepare(`
    INSERT INTO users (name, email, password, role, isBusiness, businessName, companiesHouseNumber)
    VALUES (@name, @email, @password, @role, @isBusiness, @businessName, @companiesHouseNumber)
  `);

  // Admin account
  insertUser.run({
    name: 'Admin User',
    email: 'admin@servenet.io',
    password: hashedPassword,
    role: 'admin',
    isBusiness: 0,
    businessName: null,
    companiesHouseNumber: null
  });

  // Customer account (residential)
  insertUser.run({
    name: 'Jane Smith',
    email: 'customer@servenet.io',
    password: hashedPassword,
    role: 'customer',
    isBusiness: 0,
    businessName: null,
    companiesHouseNumber: null
  });

  // Extra demo customer (business)
  insertUser.run({
    name: 'Bob Williams',
    email: 'bob@examplebiz.co.uk',
    password: hashedPassword,
    role: 'customer',
    isBusiness: 1,
    businessName: 'Williams Trading Ltd',
    companiesHouseNumber: '12345678'
  });

  console.log('[DB] Seed accounts created.');
}

// ===========================
// User Queries
// ===========================

/**
 * Find a user by email address (for login)
 */
function findUserByEmail(email) {
  const conn = getDb();
  return conn.prepare('SELECT * FROM users WHERE email = ?').get(email);
}

/**
 * Find a user by ID
 */
function findUserById(id) {
  const conn = getDb();
  return conn.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

/**
 * Get all users (for admin user list)
 */
function getAllUsers() {
  const conn = getDb();
  return conn.prepare('SELECT id, name, email, role, isBusiness, businessName, companiesHouseNumber, lastLoginTime FROM users ORDER BY id ASC').all();
}

/**
 * Update login tracking fields after successful authentication
 */
function updateLoginInfo(userId, ip, userAgent) {
  const conn = getDb();
  const now = new Date().toISOString();
  conn.prepare(`
    UPDATE users SET lastLoginTime = ?, lastLoginIP = ?, lastDevice = ? WHERE id = ?
  `).run(now, ip, userAgent, userId);
}

/**
 * Update a user's editable fields (admin action)
 */
function updateUser(id, { name, role, isBusiness, businessName, companiesHouseNumber }) {
  const conn = getDb();
  conn.prepare(`
    UPDATE users
    SET name = ?, role = ?, isBusiness = ?, businessName = ?, companiesHouseNumber = ?
    WHERE id = ?
  `).run(name, role, isBusiness ? 1 : 0, businessName || null, companiesHouseNumber || null, id);
}

// ===========================
// Audit Log Queries
// ===========================

/**
 * Create a new audit log entry
 * Called whenever an admin views, edits, or accesses a customer record
 */
function createAuditLog({ adminId, adminName, action, targetUserId, targetUserName, reason, details, ipAddress }) {
  const conn = getDb();
  conn.prepare(`
    INSERT INTO audit_logs (adminId, adminName, action, targetUserId, targetUserName, reason, details, ipAddress)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(adminId, adminName, action, targetUserId, targetUserName, reason, details || null, ipAddress || null);
}

/**
 * Get all audit logs, newest first (for admin audit page)
 */
function getAllAuditLogs() {
  const conn = getDb();
  return conn.prepare('SELECT * FROM audit_logs ORDER BY timestamp DESC').all();
}

// ===========================
// Exports
// ===========================

module.exports = {
  getDb,
  initDatabase,
  seedDatabase,
  findUserByEmail,
  findUserById,
  getAllUsers,
  updateLoginInfo,
  updateUser,
  createAuditLog,
  getAllAuditLogs
};
