# ServeNet Customer Portal (Demo)

A simple Node.js + Express web application demonstrating session-based authentication, role-based access control, and OFCOM-style audit/compliance logging.

> **⚠️ This is a testing/demo portal only — not production-ready.**

---

## Features

- **Login / Logout** with session-based authentication
- **Password hashing** with bcrypt
- **IP & device tracking** on every login
- **Role-based access**: customer portal and admin dashboard
- **Admin user management**: view, edit user records
- **OFCOM-style audit logging**: every admin action is recorded with reason, timestamp, IP
- **SQLite** persistence (zero-config database)
- **Minimal UI** — plain HTML/CSS, no frameworks

---

## Tech Stack

| Layer       | Technology         |
|-------------|--------------------|
| Runtime     | Node.js            |
| Framework   | Express.js         |
| Templates   | EJS                |
| Database    | SQLite (better-sqlite3) |
| Auth        | express-session + bcryptjs |
| Styling     | Plain CSS (ServeNet brand colours) |

---

## Project Structure

```
servenet-portal/
├── server.js              # App entry point
├── package.json
├── database/              # SQLite database file (auto-created)
├── models/
│   └── database.js        # Schema, seed data, query helpers
├── routes/
│   ├── auth.js            # Login / logout routes
│   ├── customer.js        # Customer portal routes
│   └── admin.js           # Admin dashboard routes
├── views/
│   ├── login.ejs
│   ├── error.ejs
│   ├── partials/          # Shared HTML fragments
│   │   ├── head.ejs
│   │   ├── footer.ejs
│   │   ├── navbar-admin.ejs
│   │   └── navbar-customer.ejs
│   ├── customer/
│   │   └── dashboard.ejs
│   └── admin/
│       ├── welcome.ejs
│       ├── users.ejs
│       ├── user-reason.ejs
│       ├── user-view.ejs
│       ├── user-edit.ejs
│       └── audit.ejs
└── public/
    └── css/
        └── style.css
```

---

## Setup & Run

### Prerequisites

- **Node.js** v18 or later
- **npm** (comes with Node.js)

### Installation

```bash
# 1. Navigate to the project folder
cd servenet-portal

# 2. Install dependencies
npm install

# 3. Start the server
node server.js
```

The server starts on **http://localhost:3000**.

### Seed Accounts

| Role     | Email                  | Password      |
|----------|------------------------|---------------|
| Admin    | admin@servenet.io      | ServeNet01!   |
| Customer | customer@servenet.io   | ServeNet01!   |
| Customer | bob@examplebiz.co.uk   | ServeNet01!   |

Bob's account is pre-configured as a business customer with Companies House data.

---

## Usage Guide

### Customer Portal (`/customer`)

After logging in as a customer, you'll see:
- A welcome message with your name and role
- Your account details (email, role, business status)
- Your last login information (time, IP, device)

### Admin Dashboard (`/admin`)

After logging in as an admin, you have access to three pages:

1. **Dashboard** — Welcome page with quick links
2. **Users** — Table of all users with View and Edit buttons
3. **Audit Log** — Complete compliance log of all admin actions

### Audit/Compliance Flow

When an admin clicks **View** or **Edit** on a user:

1. A **compliance gate** appears requiring the admin to select a reason
2. Available reasons: Account verification, Customer support, Billing issue, Fraud prevention, Technical support
3. After selecting a reason, the action is logged and the admin can proceed
4. All logs are visible in the Audit Log page with: admin name, action, customer name, reason, timestamp, and IP address

---

## Environment Variables (Optional)

| Variable | Default | Description          |
|----------|---------|----------------------|
| PORT     | 3000    | Server listen port   |

```bash
PORT=8080 node server.js
```

---

## Notes

- The SQLite database is auto-created at `database/servenet.db` on first run
- To reset all data, delete the `database/servenet.db` file and restart
- Sessions expire after 2 hours of inactivity
- Brand colours: Navy `#0e2a3f` and Green `#14a68b`
