/**
 * ServeNet Customer Portal v2
 * ============================
 * OFCOM-compliant demo portal with:
 * - Session auth with 10-minute admin inactivity timeout
 * - Failed login tracking with account lockout (3 attempts)
 * - Vulnerable customer flagging (OFCOM C5)
 * - Comprehensive audit logging with filtering
 * - Separate residential/business customer search
 */

const express = require('express');
const session = require('express-session');
const path = require('path');
const { initDatabase, seedDatabase } = require('./models/database');

const authRoutes = require('./routes/auth');
const customerRoutes = require('./routes/customer');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// 10 minute admin timeout (in milliseconds)
const ADMIN_TIMEOUT_MS = 10 * 60 * 1000;

// ---------------------
// Middleware
// ---------------------

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('trust proxy', true);

app.use(session({
  secret: 'servenet-demo-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 8, // 8 hour absolute max
    httpOnly: true
  }
}));

// Make user and flash messages available to all templates
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
});

/**
 * Admin inactivity timeout middleware
 * If an admin has been inactive for 10+ minutes, destroy their session
 * and force re-login. Updates lastActivity on every request.
 */
app.use((req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') {
    const now = Date.now();
    const lastActivity = req.session.lastActivity || now;
    const elapsed = now - lastActivity;

    if (elapsed > ADMIN_TIMEOUT_MS) {
      // Session timed out
      const userName = req.session.user.name;
      req.session.destroy((err) => {
        if (err) console.error('Session destroy error:', err);
        return res.redirect('/login?timeout=1');
      });
      return;
    }

    // Update activity timestamp
    req.session.lastActivity = now;
  }
  next();
});

// ---------------------
// Routes
// ---------------------

app.use('/', authRoutes);
app.use('/customer', customerRoutes);
app.use('/admin', adminRoutes);

app.get('/', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  if (req.session.user.role === 'admin') return res.redirect('/admin');
  return res.redirect('/customer');
});

// 404
app.use((req, res) => {
  res.status(404).render('error', {
    title: '404 - Page Not Found',
    message: 'The page you are looking for does not exist.'
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).render('error', {
    title: '500 - Server Error',
    message: 'Something went wrong. Please try again.'
  });
});

// ---------------------
// Start
// ---------------------

initDatabase();
seedDatabase();

app.listen(PORT, () => {
  console.log(`\n  ServeNet Portal v2 running at http://localhost:${PORT}`);
  console.log(`  ─────────────────────────────────────────────────`);
  console.log(`  Admin:    admin@servenet.io / ServeNet01!`);
  console.log(`  Customer: customer@servenet.io / ServeNet01!`);
  console.log(`  Admin timeout: 10 minutes inactivity`);
  console.log(`  Account lockout: after 3 failed attempts\n`);
});
