/**
 * ServeNet Customer Portal - Demo/Testing Application
 * =====================================================
 * A simple Node.js + Express web application with:
 * - Session-based authentication
 * - Role-based access (admin / customer)
 * - OFCOM-style audit/compliance logging
 * - Admin dashboard with user management
 *
 * NOT production-ready. Built for clarity and demonstration.
 */

const express = require('express');
const session = require('express-session');
const path = require('path');
const { initDatabase, seedDatabase } = require('./models/database');

// Import route modules
const authRoutes = require('./routes/auth');
const customerRoutes = require('./routes/customer');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// ---------------------
// Middleware Setup
// ---------------------

// Parse form data and JSON bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files (CSS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Trust proxy so req.ip works behind reverse proxies (nginx, etc.)
app.set('trust proxy', true);

// Session configuration
app.use(session({
  secret: 'servenet-demo-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 2, // 2 hour session timeout
    httpOnly: true
  }
}));

// Make session user data available to all EJS templates
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// ---------------------
// Routes
// ---------------------

// Authentication routes (login, logout)
app.use('/', authRoutes);

// Customer portal routes (requires customer or admin role)
app.use('/customer', customerRoutes);

// Admin dashboard routes (requires admin role)
app.use('/admin', adminRoutes);

// Home page - redirect based on auth status
app.get('/', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  // Redirect based on role
  if (req.session.user.role === 'admin') {
    return res.redirect('/admin');
  }
  return res.redirect('/customer');
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('error', {
    title: '404 - Page Not Found',
    message: 'The page you are looking for does not exist.'
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).render('error', {
    title: '500 - Server Error',
    message: 'Something went wrong. Please try again.'
  });
});

// ---------------------
// Initialise & Start
// ---------------------

// Set up the database tables and seed demo accounts, then start the server
initDatabase();
seedDatabase();

app.listen(PORT, () => {
  console.log(`\n  ServeNet Portal running at http://localhost:${PORT}`);
  console.log(`  ─────────────────────────────────────────────`);
  console.log(`  Admin login:    admin@servenet.io / ServeNet01!`);
  console.log(`  Customer login: customer@servenet.io / ServeNet01!\n`);
});
