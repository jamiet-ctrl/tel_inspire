-- ============================================
-- ServeNet Portal v5 — MySQL Setup
-- Run: sudo mysql < setup.sql
-- ============================================

CREATE DATABASE IF NOT EXISTS servenet_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'servenet'@'localhost' IDENTIFIED BY 'ServeNet@2026';
GRANT ALL PRIVILEGES ON servenet_portal.* TO 'servenet'@'localhost';
FLUSH PRIVILEGES;

USE servenet_portal;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  firstName VARCHAR(100) NOT NULL,
  lastName VARCHAR(100) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'customer',
  isBusiness TINYINT NOT NULL DEFAULT 0,
  businessName VARCHAR(255) DEFAULT NULL,
  companiesHouseNumber VARCHAR(20) DEFAULT NULL,
  postcode VARCHAR(10) DEFAULT NULL,
  addressLine1 VARCHAR(255) DEFAULT NULL,
  addressLine2 VARCHAR(255) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  phone VARCHAR(30) DEFAULT NULL,
  isVulnerable TINYINT NOT NULL DEFAULT 0,
  vulnerabilityNotes TEXT DEFAULT NULL,
  accountStatus VARCHAR(20) NOT NULL DEFAULT 'active',
  failedLoginAttempts INT NOT NULL DEFAULT 0,
  lockedAt DATETIME DEFAULT NULL,
  lastLoginTime DATETIME DEFAULT NULL,
  lastLoginIP VARCHAR(45) DEFAULT NULL,
  lastDevice TEXT DEFAULT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  adminId INT NOT NULL,
  adminName VARCHAR(200) NOT NULL,
  adminEmail VARCHAR(255) NOT NULL,
  action VARCHAR(50) NOT NULL,
  category VARCHAR(50) NOT NULL DEFAULT 'general',
  targetUserId INT DEFAULT NULL,
  targetUserName VARCHAR(200) DEFAULT NULL,
  targetUserEmail VARCHAR(255) DEFAULT NULL,
  reason VARCHAR(255) NOT NULL,
  details TEXT DEFAULT NULL,
  previousValues TEXT DEFAULT NULL,
  newValues TEXT DEFAULT NULL,
  ipAddress VARCHAR(45) DEFAULT NULL,
  userAgent TEXT DEFAULT NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_admin (adminId),
  INDEX idx_audit_target (targetUserId),
  INDEX idx_audit_action (action),
  INDEX idx_audit_ts (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  ipAddress VARCHAR(45) DEFAULT NULL,
  userAgent TEXT DEFAULT NULL,
  success TINYINT NOT NULL DEFAULT 0,
  failureReason VARCHAR(255) DEFAULT NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_email (email),
  INDEX idx_login_ts (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT NOT NULL,
  serviceType VARCHAR(50) NOT NULL,
  serviceName VARCHAR(255) NOT NULL,
  serviceRef VARCHAR(50) DEFAULT NULL,
  mobileNumber VARCHAR(20) DEFAULT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  startDate DATETIME DEFAULT CURRENT_TIMESTAMP,
  monthlyCost DECIMAL(10,2) DEFAULT 0.00,
  notes TEXT DEFAULT NULL,
  INDEX idx_svc_user (userId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  targetAdminId INT DEFAULT NULL,
  relatedUserId INT DEFAULT NULL,
  isRead TINYINT NOT NULL DEFAULT 0,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notif_admin (targetAdminId),
  INDEX idx_notif_read (isRead)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
