# Telecom/ISP Management System

Audit-hardened customer billing and management system built for UK Ofcom compliance and GDPR.

## Features

- ✓ **Ofcom Compliant**: General Conditions C4 (complaints) and C5 (vulnerable customers)
- ✓ **GDPR Request Tracking**: Subject access, erasure, portability with 1-month deadline monitoring
- ✓ **Tamper-Evident Audit Log**: SHA-256 hash chain - detects any unauthorized changes
- ✓ **Vulnerable Customer Protection**: Automatic flagging and access logging
- ✓ **Role-Based Access Control**: Viewer, Agent, Supervisor, Compliance Officer, Admin
- ✓ **Sensitive Field Logging**: Every access to NI numbers, DOB logged with staff ID and reason

## Tech Stack

- **Backend**: Node.js + Express
- **Database**: MariaDB / MySQL
- **Views**: EJS templates
- **Session Management**: express-session
- **Security**: bcryptjs, helmet, rate-limiting

---

## VPS Setup Instructions

### 1. Prerequisites

SSH into your VPS and install Node.js and MariaDB:

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js (v18 LTS)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install MariaDB
sudo apt install -y mariadb-server

# Secure MariaDB
sudo mysql_secure_installation
```

### 2. Set Up Database

Log into MariaDB:

```bash
sudo mysql -u root -p
```

Create the database and user:

```sql
CREATE DATABASE telecom_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'telecom_user'@'localhost' IDENTIFIED BY 'your_secure_password_here';
GRANT ALL PRIVILEGES ON telecom_db.* TO 'telecom_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

Import the database schema:

```bash
mysql -u telecom_user -p telecom_db < customers.sql
```

### 3. Deploy Application

Upload the app to your VPS (via FTP, git, or rsync):

```bash
# Example using rsync from your local machine:
rsync -avz ./telecom-app/ user@your-vps-ip:/var/www/telecom-app/
```

On your VPS, navigate to the app directory:

```bash
cd /var/www/telecom-app
```

Install dependencies:

```bash
npm install
```

### 4. Configure Environment

Create a `.env` file:

```bash
cp .env.example .env
nano .env
```

Fill in your database credentials:

```env
DB_HOST=localhost
DB_USER=telecom_user
DB_PASSWORD=your_secure_password_here
DB_NAME=telecom_db
DB_PORT=3306

SESSION_SECRET=generate_a_random_string_here
PORT=3000
NODE_ENV=production
```

**IMPORTANT**: Generate a strong random string for `SESSION_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 5. Create First Admin User

You need to manually insert the first staff user with a hashed password:

```bash
# Generate a bcrypt hash for your password
node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('your_password_here', 10, (e,h) => console.log(h));"
```

Copy the hash, then in MariaDB:

```sql
USE telecom_db;

INSERT INTO staff_users (staff_id, username, email_address, first_name, last_name, role, password_hash)
VALUES (
    UUID(),
    'admin',
    'admin@yourcompany.com',
    'System',
    'Administrator',
    'admin',
    'paste_bcrypt_hash_here'
);
```

### 6. Run the Application

For testing:

```bash
npm start
```

For production with PM2 (recommended):

```bash
# Install PM2 globally
sudo npm install -g pm2

# Start the app
pm2 start server.js --name telecom-app

# Make it start on boot
pm2 startup
pm2 save
```

### 7. Set Up Reverse Proxy (Nginx)

Install Nginx:

```bash
sudo apt install -y nginx
```

Create a config file:

```bash
sudo nano /etc/nginx/sites-available/telecom-app
```

Paste this configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/telecom-app /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 8. Set Up HTTPS (Let's Encrypt)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

Follow the prompts. Certbot will automatically configure SSL and set up auto-renewal.

---

## Usage

### Login Credentials

Use the admin account you created in step 5:

- **Username**: `admin`
- **Password**: whatever you set in the bcrypt hash

### Admin Features

- **Dashboard**: View system stats (total customers, vulnerable customers, open complaints, overdue GDPR requests)
- **Customers**: Browse, search, and view detailed customer records
- **Complaints**: Manage customer complaints (Ofcom C4 requirement)
- **GDPR Requests**: Track data subject requests (Compliance Officer+ only)

### Role Permissions

| Feature | Viewer | Agent | Supervisor | Compliance Officer | Admin |
|---------|--------|-------|------------|-------------------|-------|
| View customers (masked) | ✓ | ✓ | ✓ | ✓ | ✓ |
| View sensitive fields | ✗ | ✗ | ✓ | ✓ | ✓ |
| Edit customers | ✗ | ✓ | ✓ | ✓ | ✓ |
| View GDPR requests | ✗ | ✗ | ✗ | ✓ | ✓ |
| Manage staff | ✗ | ✗ | ✗ | ✗ | ✓ |

---

## Security Features

### Audit Logging

Every INSERT, UPDATE, DELETE on customers, complaints, and GDPR requests is automatically logged with:
- Who made the change
- What changed (field-level)
- When it happened
- IP address

### Hash Chain

The `audit_log` table uses a SHA-256 hash chain. Each row contains:
- `row_hash`: SHA-256 of (row content + previous row's hash)
- `previous_hash`: The hash of the row before it

To verify integrity:

```sql
CALL verify_audit_chain();
```

This will show any tampered rows.

### Sensitive Field Access Logging

Every time a supervisor+ views a customer's:
- Date of birth
- National Insurance number
- Admin notes

...it gets logged in `sensitive_field_access_log` with the staff member's ID.

---

## Maintenance

### View Logs

```bash
pm2 logs telecom-app
```

### Restart App

```bash
pm2 restart telecom-app
```

### Database Backup

```bash
mysqldump -u telecom_user -p telecom_db > backup_$(date +%Y%m%d).sql
```

### Monitor Process

```bash
pm2 monit
```

---

## Troubleshooting

**Can't connect to database**:
- Check `.env` credentials
- Verify MariaDB is running: `sudo systemctl status mariadb`

**404 on all routes**:
- Check Nginx config
- Verify app is running: `pm2 status`

**Session not persisting**:
- Make sure `SESSION_SECRET` is set in `.env`
- In production, use a proper session store (e.g., Redis)

---

## License

Proprietary. Built for internal use.
