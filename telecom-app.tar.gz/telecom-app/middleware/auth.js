// Check if user is logged in
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next();
    }
    res.redirect('/auth/login');
}

// Check if user is admin/staff
function isStaff(req, res, next) {
    if (req.session.user && req.session.user.type === 'staff') {
        return next();
    }
    res.status(403).render('error', { error: 'Access denied. Staff only.' });
}

// Check if user is customer
function isCustomer(req, res, next) {
    if (req.session.user && req.session.user.type === 'customer') {
        return next();
    }
    res.status(403).render('error', { error: 'Access denied. Customers only.' });
}

// Check specific staff roles
function hasRole(...roles) {
    return (req, res, next) => {
        if (req.session.user && 
            req.session.user.type === 'staff' && 
            roles.includes(req.session.user.role)) {
            return next();
        }
        res.status(403).render('error', { 
            error: `Access denied. Requires one of: ${roles.join(', ')}` 
        });
    };
}

module.exports = {
    isAuthenticated,
    isStaff,
    isCustomer,
    hasRole
};
