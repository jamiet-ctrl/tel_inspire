const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isCustomer } = require('../middleware/auth');

// All customer routes require customer login
router.use(isCustomer);

// Customer portal home
router.get('/portal', async (req, res) => {
    try {
        const customerId = req.session.user.id;

        // Get customer details
        const [customers] = await db.query(
            'SELECT * FROM customers WHERE customer_id = ?',
            [customerId]
        );

        if (customers.length === 0) {
            return res.status(404).render('error', { error: 'Customer not found' });
        }

        const customer = customers[0];

        // Get recent complaints
        const [complaints] = await db.query(
            'SELECT * FROM customer_complaints WHERE customer_id = ? ORDER BY complaint_date DESC LIMIT 5',
            [customerId]
        );

        res.render('customer/portal', {
            customer,
            complaints
        });
    } catch (err) {
        console.error('Customer portal error:', err);
        res.render('error', { error: 'Failed to load portal' });
    }
});

// Customer account details
router.get('/account', async (req, res) => {
    try {
        const [customers] = await db.query(
            'SELECT * FROM customers WHERE customer_id = ?',
            [req.session.user.id]
        );

        res.render('customer/account', { customer: customers[0] });
    } catch (err) {
        console.error('Account error:', err);
        res.render('error', { error: 'Failed to load account' });
    }
});

module.exports = router;
