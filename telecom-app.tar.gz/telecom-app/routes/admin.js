const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isStaff, hasRole } = require('../middleware/auth');

// All admin routes require staff login
router.use(isStaff);

// Admin Dashboard
router.get('/dashboard', async (req, res) => {
    try {
        // Get summary stats
        const [customerCount] = await db.query(
            'SELECT COUNT(*) as total FROM customers'
        );
        const [activeCustomers] = await db.query(
            'SELECT COUNT(*) as total FROM customers WHERE account_status = ?',
            ['active']
        );
        const [vulnerableCustomers] = await db.query(
            'SELECT COUNT(*) as total FROM customers WHERE is_vulnerable = 1'
        );
        const [openComplaints] = await db.query(
            'SELECT COUNT(*) as total FROM customer_complaints WHERE status IN (?, ?)',
            ['open', 'under_review']
        );
        const [overdueGDPR] = await db.query(
            'SELECT COUNT(*) as total FROM gdpr_requests WHERE completed_at IS NULL AND NOW() > deadline_at'
        );

        res.render('admin/dashboard', {
            stats: {
                totalCustomers: customerCount[0].total,
                activeCustomers: activeCustomers[0].total,
                vulnerableCustomers: vulnerableCustomers[0].total,
                openComplaints: openComplaints[0].total,
                overdueGDPR: overdueGDPR[0].total
            }
        });
    } catch (err) {
        console.error('Dashboard error:', err);
        res.render('error', { error: 'Failed to load dashboard' });
    }
});

// Customer List — uses the safe view for most staff, full table for supervisors+
router.get('/customers', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = 50;
        const offset = (page - 1) * limit;
        const search = req.query.search || '';

        // Use safe view for viewer/agent roles, full table for supervisor+
        const canViewSensitive = ['supervisor', 'compliance_officer', 'admin'].includes(req.session.user.role);
        const tableName = canViewSensitive ? 'customers' : 'customer_safe_view';

        let query = `SELECT * FROM ${tableName}`;
        let countQuery = `SELECT COUNT(*) as total FROM ${tableName}`;
        const params = [];

        if (search) {
            query += ` WHERE customer_id LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email_address LIKE ? OR postcode LIKE ?`;
            countQuery += ` WHERE customer_id LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email_address LIKE ? OR postcode LIKE ?`;
            const searchTerm = `%${search}%`;
            params.push(searchTerm, searchTerm, searchTerm, searchTerm, searchTerm);
        }

        query += ` ORDER BY account_created_at DESC LIMIT ? OFFSET ?`;

        const [customers] = await db.query(query, [...params, limit, offset]);
        const [totalResult] = await db.query(countQuery, params);
        const total = totalResult[0].total;
        const totalPages = Math.ceil(total / limit);

        res.render('admin/customers', {
            customers,
            currentPage: page,
            totalPages,
            search,
            canViewSensitive
        });
    } catch (err) {
        console.error('Customer list error:', err);
        res.render('error', { error: 'Failed to load customers' });
    }
});

// View single customer — full details
router.get('/customers/:id', async (req, res) => {
    try {
        const canViewSensitive = ['supervisor', 'compliance_officer', 'admin'].includes(req.session.user.role);

        const [customers] = await db.query(
            'SELECT * FROM customers WHERE customer_id = ?',
            [req.params.id]
        );

        if (customers.length === 0) {
            return res.status(404).render('error', { error: 'Customer not found' });
        }

        const customer = customers[0];

        // Log sensitive field access if they're viewing sensitive data
        if (canViewSensitive) {
            await db.query(
                `INSERT INTO sensitive_field_access_log 
                (customer_id, staff_id, fields_accessed, access_reason, accessed_at, ip_address)
                VALUES (?, ?, ?, ?, NOW(3), ?)`,
                [
                    customer.customer_id,
                    req.session.user.id,
                    JSON.stringify(['date_of_birth', 'national_insurance_no']),
                    'Viewed customer details page',
                    req.ip
                ]
            );
        }

        // Get complaints
        const [complaints] = await db.query(
            'SELECT * FROM customer_complaints WHERE customer_id = ? ORDER BY complaint_date DESC',
            [req.params.id]
        );

        // Get GDPR requests
        const [gdprRequests] = await db.query(
            'SELECT * FROM gdpr_requests WHERE customer_id = ? ORDER BY received_at DESC',
            [req.params.id]
        );

        // Get recent audit log entries
        const [auditLog] = await db.query(
            `SELECT al.*, su.username as staff_username 
             FROM audit_log al
             LEFT JOIN staff_users su ON al.performed_by = su.staff_id
             WHERE al.customer_id = ? 
             ORDER BY al.performed_at DESC 
             LIMIT 20`,
            [req.params.id]
        );

        res.render('admin/customer-detail', {
            customer,
            complaints,
            gdprRequests,
            auditLog,
            canViewSensitive
        });
    } catch (err) {
        console.error('Customer detail error:', err);
        res.render('error', { error: 'Failed to load customer details' });
    }
});

// Complaints list
router.get('/complaints', async (req, res) => {
    try {
        const [complaints] = await db.query(
            `SELECT cc.*, c.first_name, c.last_name, c.email_address
             FROM customer_complaints cc
             JOIN customers c ON cc.customer_id = c.customer_id
             ORDER BY cc.complaint_date DESC
             LIMIT 100`
        );

        res.render('admin/complaints', { complaints });
    } catch (err) {
        console.error('Complaints error:', err);
        res.render('error', { error: 'Failed to load complaints' });
    }
});

// GDPR requests — compliance officer+ only
router.get('/gdpr-requests', hasRole('compliance_officer', 'admin'), async (req, res) => {
    try {
        const [requests] = await db.query(
            `SELECT gr.*, c.first_name, c.last_name, c.email_address,
                    su.username as handled_by_username
             FROM gdpr_requests gr
             JOIN customers c ON gr.customer_id = c.customer_id
             LEFT JOIN staff_users su ON gr.handled_by = su.staff_id
             ORDER BY gr.received_at DESC`
        );

        res.render('admin/gdpr-requests', { requests });
    } catch (err) {
        console.error('GDPR requests error:', err);
        res.render('error', { error: 'Failed to load GDPR requests' });
    }
});

module.exports = router;
