const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/database');

// Login page
router.get('/login', (req, res) => {
    res.render('login', { error: null });
});

// Login POST — handles both staff and customer login
router.post('/login', async (req, res) => {
    const { username, password, loginType } = req.body;

    try {
        let user = null;
        let userType = null;

        if (loginType === 'staff') {
            // Staff login
            const [rows] = await db.query(
                'SELECT * FROM staff_users WHERE username = ? AND is_active = 1',
                [username]
            );

            if (rows.length === 0) {
                return res.render('login', { error: 'Invalid credentials' });
            }

            user = rows[0];
            const match = await bcrypt.compare(password, user.password_hash);

            if (!match) {
                return res.render('login', { error: 'Invalid credentials' });
            }

            // Update last login
            await db.query(
                'UPDATE staff_users SET last_login_at = NOW(3) WHERE staff_id = ?',
                [user.staff_id]
            );

            req.session.user = {
                id: user.staff_id,
                username: user.username,
                name: `${user.first_name} ${user.last_name}`,
                role: user.role,
                type: 'staff'
            };

            res.redirect('/admin/dashboard');

        } else if (loginType === 'customer') {
            // Customer login — username is their email address
            const [rows] = await db.query(
                'SELECT * FROM customers WHERE email_address = ? AND account_status = ?',
                [username, 'active']
            );

            if (rows.length === 0) {
                return res.render('login', { error: 'Invalid credentials or account not active' });
            }

            user = rows[0];

            // NOTE: Customers don't have passwords in the current schema!
            // You'll need to add a password_hash column to the customers table.
            // For now, we'll just reject customer logins:
            return res.render('login', { 
                error: 'Customer login not yet implemented. Please contact support.' 
            });

            // When you add password_hash to customers table, uncomment this:
            /*
            const match = await bcrypt.compare(password, user.password_hash);
            if (!match) {
                return res.render('login', { error: 'Invalid credentials' });
            }

            req.session.user = {
                id: user.customer_id,
                name: `${user.first_name} ${user.last_name}`,
                email: user.email_address,
                type: 'customer'
            };

            res.redirect('/customer/portal');
            */
        } else {
            return res.render('login', { error: 'Invalid login type' });
        }

    } catch (err) {
        console.error('Login error:', err);
        res.render('login', { error: 'An error occurred. Please try again.' });
    }
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

module.exports = router;
