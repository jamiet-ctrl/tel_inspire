const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { findUserById, updateUserProfile, updateUserPassword } = require('../models/database');

function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}
router.use(requireAuth);

router.get('/', (req, res) => {
  const user = findUserById(req.session.user.id);
  if (!user) return res.redirect('/logout');
  res.render('customer/dashboard', { title: 'My Account', user });
});

router.get('/settings', (req, res) => {
  const user = findUserById(req.session.user.id);
  res.render('customer/settings', {
    title: 'Settings', user, activePage: 'settings',
    success: null, error: null, tab: req.query.tab || 'profile'
  });
});

router.post('/settings/profile', (req, res) => {
  const { firstName, lastName, phone, addressLine1, addressLine2, city, postcode } = req.body;
  if (!firstName?.trim() || !lastName?.trim()) {
    const user = findUserById(req.session.user.id);
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'First and last name are required.', tab: 'profile'
    });
  }
  updateUserProfile(req.session.user.id, {
    firstName: firstName.trim(), lastName: lastName.trim(),
    phone: phone?.trim() || null, addressLine1: addressLine1?.trim() || null,
    addressLine2: addressLine2?.trim() || null, city: city?.trim() || null,
    postcode: postcode?.trim().toUpperCase() || null
  });
  req.session.user.name = `${firstName.trim()} ${lastName.trim()}`;
  const user = findUserById(req.session.user.id);
  res.render('customer/settings', {
    title: 'Settings', user, activePage: 'settings',
    success: 'Profile updated.', error: null, tab: 'profile'
  });
});

router.post('/settings/password', (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const user = findUserById(req.session.user.id);

  if (!currentPassword || !newPassword || !confirmPassword) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'All password fields are required.', tab: 'password'
    });
  }
  if (!bcrypt.compareSync(currentPassword, user.password)) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'Current password is incorrect.', tab: 'password'
    });
  }
  if (newPassword.length < 8) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'New password must be at least 8 characters.', tab: 'password'
    });
  }
  if (newPassword !== confirmPassword) {
    return res.render('customer/settings', {
      title: 'Settings', user, activePage: 'settings',
      success: null, error: 'Passwords do not match.', tab: 'password'
    });
  }
  updateUserPassword(user.id, bcrypt.hashSync(newPassword, 10));
  const refreshed = findUserById(req.session.user.id);
  res.render('customer/settings', {
    title: 'Settings', user: refreshed, activePage: 'settings',
    success: 'Password changed.', error: null, tab: 'password'
  });
});

module.exports = router;
