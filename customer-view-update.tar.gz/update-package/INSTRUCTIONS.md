# Customer View Update Instructions

## What This Fixes

1. ✅ Customer list now shows ONLY: ID, Name, Email, Status (no contract dates or vulnerable flags visible)
2. ✅ "View Details" button now works properly
3. ✅ Full customer detail page shows:
   - Alert badges for vulnerable customers, overdue GDPR requests, open complaints
   - All customer information organized in cards
   - Contract information (or "Rolling contract" if no end date)
   - Complaints history
   - GDPR requests
   - Recent audit activity
4. ✅ Sensitive fields (DOB, NI number, admin notes) only visible to supervisor+ roles
5. ✅ Access to sensitive fields is automatically logged

## Files to Update

### 1. Replace `views/admin/customers.ejs`
```bash
cd /var/www/tel_inspire/telecom-app
cp customers-updated.ejs views/admin/customers.ejs
```

### 2. Replace `views/admin/customer-detail.ejs`
```bash
cp customer-detail-updated.ejs views/admin/customer-detail.ejs
```

### 3. Replace `routes/admin.js`
```bash
cp admin-routes-updated.js routes/admin.js
```

### 4. Add new styles to `public/css/style.css`
```bash
cat customer-detail-styles.css >> public/css/style.css
```

### 5. Restart PM2
```bash
pm2 restart telecom-app
```

## What You'll See

### Customer List (http://185.123.45.67/admin/customers)
- Simple table with just: ID | Name | Email | Status | View Details button
- No sensitive information visible at a glance

### Customer Detail Page (click "View Details")
- **Alert badges** at the top if:
  - Customer is vulnerable (shows reasons and notes)
  - Has overdue GDPR requests
  - Has open complaints
- **Information cards** for:
  - Personal info (DOB/NI only for supervisors+)
  - Contact details
  - Address
  - Contract info (shows "Rolling contract" if no end date)
  - Marketing consent
  - Notes
- **Tables** for:
  - Complaints history
  - GDPR requests
  - Recent audit activity
- **Actions**: Edit button (placeholder for now)

## Role-Based Access

| Field                    | Viewer | Agent | Supervisor+ |
|--------------------------|--------|-------|-------------|
| Customer list (basic)    | ✓      | ✓     | ✓           |
| View full details        | ✓      | ✓     | ✓           |
| See DOB/NI number        | ✗      | ✗     | ✓           |
| See admin notes          | ✗      | ✗     | ✓           |
| Sensitive access logged  | n/a    | n/a   | ✓           |

Every time a supervisor+ views a customer detail page, it logs to `sensitive_field_access_log`.

## Test It

1. Log in as admin
2. Go to Customers
3. Click "View Details" on Jamie Thompson
4. You should see:
   - Full customer info in organized cards
   - Contract info showing "01/06/2025" end date
   - No alert badges (customer is not vulnerable, no complaints, no GDPR requests)

## Need Edit Functionality?

The "Edit Customer" button is there but goes to a placeholder route. Want me to build the edit form next?
