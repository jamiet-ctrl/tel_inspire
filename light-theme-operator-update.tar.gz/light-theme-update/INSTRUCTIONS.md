# Light Theme + Edit Functionality Update

## What's New

### ✅ Light Theme
- Clean, professional white background
- High contrast for easy reading
- Optimized for call center operators
- Print-friendly

### ✅ BIG RED VULNERABLE FLAG
- Impossible to miss at top of page
- Shows reasons in CAPS
- Includes vulnerability notes
- Animated glow effect

### ✅ Edit Customer Information
- Modal popup for editing
- **Required audit reason** for every change (Ofcom compliance)
- Logs who, what, when, why
- Staff name + timestamp automatically recorded

### ✅ Manage Vulnerable Status
- Easy checkbox interface
- Select multiple vulnerability reasons
- Add detailed notes
- **Required change reason** (Ofcom C5)
- Fully audited

### ✅ Operator-Friendly Layout
- Quick action buttons at top
- Streamlined information cards
- Easy navigation on phone calls
- Print button for records

---

## Installation

### On your VPS:

```bash
# Navigate to app directory
cd /var/www/tel_inspire/telecom-app

# Backup current files (just in case)
cp public/css/style.css public/css/style-dark-backup.css
cp views/admin/customer-detail.ejs views/admin/customer-detail-old.ejs
cp routes/admin.js routes/admin-old.js

# Apply updates (assuming you uploaded light-theme-update folder)
cp ~/light-theme-update/style.css public/css/style.css
cp ~/light-theme-update/customer-detail.ejs views/admin/customer-detail.ejs
cp ~/light-theme-update/admin.js routes/admin.js

# Restart
pm2 restart telecom-app
```

---

## Features Overview

### 1. Vulnerable Customer Alert
When viewing a vulnerable customer, you'll see a **BIG RED BOX** at the top:

```
🚨 VULNERABLE CUSTOMER - SPECIAL CARE REQUIRED
Reasons: FINANCIAL DIFFICULTY, MENTAL HEALTH
Notes: Customer struggling with payments since job loss...
⚠️ Follow Ofcom C5 guidelines
```

### 2. Quick Actions Bar
Four buttons at the top:
- ✏️ **Edit Customer** - Update details
- 🖨️ **Print Profile** - Print current view
- ⚠️ **Flag as Vulnerable** or **Manage Vulnerability**
- 📋 **X Open Complaints** (if any)

### 3. Edit Customer Modal
Click "Edit Customer" to open a form with:
- First name, last name, email
- Phone numbers
- Customer notes
- Admin notes (supervisor+ only)
- **Reason for changes** (required field)

Example reason: "Customer requested phone number update during call"

All changes are logged to `audit_log` with:
- Staff member who made the change
- Exact timestamp
- Reason provided
- What fields changed

### 4. Manage Vulnerability Modal
Click the vulnerability button to:
- Check/uncheck "Mark as Vulnerable"
- Select reasons (checkboxes):
  - Financial Difficulty
  - Mental Health
  - Physical Disability
  - Learning Disability
  - Elderly or Age Related
  - Bereavement
  - Domestic Abuse
  - Serious Illness
  - Carer Responsibilities
  - English Not First Language
  - Other
- Add detailed notes
- **Reason for update** (required)

Example reason: "Customer disclosed financial difficulties during call"

---

## Audit Trail

Every edit creates two audit records:

1. **Automatic trigger** from the database (tracks the actual SQL change)
2. **Manual entry** with the reason (tracks WHY it changed)

View audit trail at bottom of customer page under "Recent Activity"

---

## Test It

1. Log in as admin
2. Go to Customers → View Details on any customer
3. You should see:
   - Light theme (white background)
   - Quick actions at top
   - Clean card layout
4. Click "Edit Customer"
   - Fill in a reason
   - Save
5. Check "Recent Activity" section
   - Your change is logged with reason

---

## Vulnerable Customer Test

To see the BIG RED FLAG:

```sql
-- In MySQL/MariaDB
UPDATE customers 
SET is_vulnerable = 1,
    vulnerability_reasons = '["financial_difficulty","mental_health"]',
    vulnerability_notes = 'Test vulnerability flag',
    vulnerability_flagged_at = NOW()
WHERE customer_id = 'JT82NV';
```

Refresh the customer page - you'll see the red alert at the top.

---

## Ofcom Compliance

✅ **Every change is logged** - who, what, when, WHY
✅ **Vulnerable customers clearly flagged** - impossible to miss
✅ **Staff accountability** - reason required for all changes
✅ **Audit trail** - full history visible on customer page
✅ **Role-based access** - sensitive fields protected

---

## Need Dark Theme Back?

Your old dark theme is backed up as `style-dark-backup.css`

To switch back:
```bash
cd /var/www/tel_inspire/telecom-app/public/css
cp style-dark-backup.css style.css
pm2 restart telecom-app
```

---

## Issues?

If edit buttons don't work:
1. Check browser console for errors (F12)
2. Make sure JavaScript is enabled
3. Check PM2 logs: `pm2 logs telecom-app`

If vulnerable flag doesn't show:
1. Make sure `is_vulnerable = 1` in database
2. Check that `vulnerability_reasons` is valid JSON array
3. Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
